import type { SPFI } from '@pnp/sp';
import type { IItems } from '@pnp/sp/items';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/batching';
/**
 * Select a SharePoint list by exact title, GUID, decoded server-relative root URL
 * or decoded root path relative to the supplied client's explicit web.
 * String targets always remain titles; URL/path request escaping is owned by PnPjs.
 */
export type SPFxPnPListSelector = {
    readonly kind: 'title';
    readonly title: string;
} | {
    readonly kind: 'id';
    readonly id: string;
} | {
    readonly kind: 'url';
    readonly serverRelativeUrl: string;
} | {
    readonly kind: 'path';
    readonly webRelativePath: string;
};
export type SPFxPnPListQueryBuilder = (items: IItems) => IItems;
export interface SPFxPnPListQueryOptions {
    pageSize?: number;
}
export interface SPFxPnPListQueryResult<T> {
    readonly items: T[];
    readonly effectivePageSize: number | undefined;
    readonly hasMore: boolean;
    readonly nextSkip: number;
}
export interface SPFxPnPListBatchResult<TValue> {
    readonly value: TValue;
    readonly errors: unknown[];
    readonly summaryError: Error | undefined;
}
export interface SPFxPnPListService<T = unknown> {
    query: (queryBuilder?: SPFxPnPListQueryBuilder, options?: SPFxPnPListQueryOptions) => Promise<SPFxPnPListQueryResult<T>>;
    loadMore: (queryBuilder: SPFxPnPListQueryBuilder, pageSize: number, skip: number) => Promise<SPFxPnPListQueryResult<T>>;
    getById: (id: number) => Promise<T>;
    create: (item: Partial<T>) => Promise<number>;
    update: (id: number, item: Partial<T>) => Promise<void>;
    remove: (id: number) => Promise<void>;
    createBatch: (items: Partial<T>[]) => Promise<SPFxPnPListBatchResult<number[]>>;
    updateBatch: (updates: Array<{
        id: number;
        item: Partial<T>;
    }>) => Promise<SPFxPnPListBatchResult<void>>;
    removeBatch: (ids: number[]) => Promise<SPFxPnPListBatchResult<void>>;
}
/**
 * Create list operations using the supplied PnP client and a captured list target.
 * This module registers PnP webs, lists, items and batching; it does not require
 * the toolkit context factory. The client still needs authentication and request
 * behaviors. Import other PnP features explicitly for direct client operations.
 *
 * @param sp - Configured client; batch operations use its own batched client.
 * @param listTarget - Exact title string or explicit list selector. GUIDs accept paired
 * braces and surrounding whitespace. URL/path roots are decoded values; path selectors
 * require an explicit HTTP(S) web base on the operation's client.
 * @param defaultPageSize - Default query size when neither options nor `.top()` override it.
 * @returns List query, item CRUD and batch operations. Selector validation rejects lazily
 * from operations, including empty batches; constructing the service does not validate.
 */
export declare function createSPFxPnPListService<T = unknown>(sp: SPFI, listTarget: string | SPFxPnPListSelector, defaultPageSize?: number): SPFxPnPListService<T>;
//# sourceMappingURL=spfx-pnp-list.service.d.ts.map