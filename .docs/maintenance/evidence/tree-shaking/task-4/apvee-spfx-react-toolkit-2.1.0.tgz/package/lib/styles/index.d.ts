/**
 * Public typed style descriptors and the canonical class composer.
 * Importing descriptors does not insert CSS. Token styles need theme variables
 * in scope; useSx uses the existing Griffel renderer without an SPFx provider.
 * @example
 * ```tsx
 * import { useSx, width, padding } from '@apvee/spfx-react-toolkit/styles';
 * const sx = useSx();
 * const className = sx(width.full, padding.medium);
 * ```
 */
export * from '../helpers/styles';
export { useSx } from '../hooks/useSx';
//# sourceMappingURL=index.d.ts.map