import type { IReadonlyTheme } from '@microsoft/sp-component-base';
/**
 * Hook to access the current SPFx theme
 *
 * Theme subscription is managed automatically by SPFx providers.
 * Updates when user switches between light/dark theme or theme settings change.
 *
 * @returns Current theme object or undefined if not yet loaded
 *
 * @see {@link useSPFxFluent9ThemeInfo} for Fluent UI 9 theme conversion
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const theme = useSPFxThemeInfo();
 *
 *   return (
 *     <div style={{
 *       backgroundColor: theme?.semanticColors.bodyBackground,
 *       color: theme?.semanticColors.bodyText
 *     }}>
 *       Themed content
 *     </div>
 *   );
 * }
 * ```
 */
export declare function useSPFxThemeInfo(): IReadonlyTheme | undefined;
//# sourceMappingURL=useSPFxThemeInfo.d.ts.map