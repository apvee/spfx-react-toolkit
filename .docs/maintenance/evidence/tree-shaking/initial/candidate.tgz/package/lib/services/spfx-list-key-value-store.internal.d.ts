import { SPHttpClient } from '@microsoft/sp-http';
export interface SPFxListKeyValueStoreItem<T = unknown> {
    readonly key: string;
    readonly value: T;
    readonly description: string | undefined;
    readonly id: number;
}
export interface SPFxListKeyValueStoreService {
    ensureListReady: (webUrl: string) => Promise<void>;
    get: <T = unknown>(key: string, webUrl: string) => Promise<SPFxListKeyValueStoreItem<T> | undefined>;
    list: (webUrl: string) => Promise<SPFxListKeyValueStoreItem<unknown>[]>;
    save: <T = unknown>(key: string, value: T, webUrl: string, description?: string) => Promise<void>;
    remove: (key: string, webUrl: string) => Promise<void>;
}
export declare function createSPFxListKeyValueStoreService(spHttpClient: SPHttpClient, profile: 'tenant' | 'site'): SPFxListKeyValueStoreService;
//# sourceMappingURL=spfx-list-key-value-store.internal.d.ts.map