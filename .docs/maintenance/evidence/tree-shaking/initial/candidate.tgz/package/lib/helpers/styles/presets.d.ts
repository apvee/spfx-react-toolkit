import { SxBaseDescriptor } from './types';
/** Applies colorNeutralBackground1 background and colorNeutralForeground1 foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.canvas, typography.body1)
 */
export declare const canvas: SxBaseDescriptor;
/** Applies colorNeutralBackground2 background and colorNeutralForeground1 foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.alternative, typography.body1)
 */
export declare const alternative: SxBaseDescriptor;
/** Applies colorSubtleBackground background and colorNeutralForeground2 foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.subtle, typography.body1)
 */
export declare const subtle: SxBaseDescriptor;
/** Applies colorTransparentBackground background; leaves color inherited.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.transparent, typography.body1)
 */
export declare const transparent: SxBaseDescriptor;
/** Applies colorBrandBackground background and colorNeutralForegroundOnBrand foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.brand, typography.body1)
 */
export declare const brand: SxBaseDescriptor;
/** Applies colorBrandBackground2 background and colorBrandForeground2 foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.brandTint, typography.body1)
 */
export declare const brandTint: SxBaseDescriptor;
/** Applies colorNeutralBackgroundInverted background and colorNeutralForegroundInverted foreground.
 * Supported for verified light/dark surfaces; the floor high-contrast theme has 1:1 contrast.
 * Use canvas/alternative for content in that high-contrast theme.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.inverted, typography.body1)
 */
export declare const inverted: SxBaseDescriptor;
/** Applies colorStatusSuccessBackground1 background and colorStatusSuccessForeground1 foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.success, typography.body1)
 */
export declare const success: SxBaseDescriptor;
/** Applies colorStatusWarningBackground1 background and colorStatusWarningForeground1 foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.warning, typography.body1)
 */
export declare const warning: SxBaseDescriptor;
/** Applies colorStatusDangerBackground1 background and colorStatusDangerForeground1 foreground.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.danger, typography.body1)
 */
export declare const danger: SxBaseDescriptor;
/** Applies colorNeutralBackgroundDisabled background and colorNeutralForegroundDisabled foreground.
 * For actual disabled presentation only; light/dark floor pairs have low text contrast.
 * Does not disable the element or assign aria-disabled.
 * Requires scoped Fluent theme variables; adds no geometry or interaction states.
 * Verify contrast on the actual surface, especially for transparent/subtle/disabled.
 * @example sx(presets.disabled, typography.body1)
 */
export declare const disabled: SxBaseDescriptor;
//# sourceMappingURL=presets.d.ts.map