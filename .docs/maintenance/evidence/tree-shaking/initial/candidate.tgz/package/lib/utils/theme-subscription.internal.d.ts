import type { IReadonlyTheme } from '@microsoft/sp-component-base';
/**
 * Hook to subscribe to SPFx theme changes
 *
 * Automatically updates the provided setter when theme changes.
 * Sets initial theme on mount and subscribes to themeChangedEvent.
 *
 * @param spfxContext - SPFx context object with serviceScope
 * @param setTheme - Setter function to update theme state (receives IReadonlyTheme or undefined)
 * @returns void - Hook manages subscription lifecycle internally
 *
 * @remarks
 * - Initial theme is set synchronously on mount if available
 * - Cleanup removes event listener automatically on unmount
 * - Uses SPFx observer pattern for event subscription
 *
 * @internal
 */
export declare function useThemeSubscription(spfxContext: unknown, setTheme: (theme: IReadonlyTheme | undefined) => void, isScopeReady: boolean): void;
//# sourceMappingURL=theme-subscription.internal.d.ts.map