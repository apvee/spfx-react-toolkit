import { SxBaseDescriptor } from './types';
/** Fluent scrollbar appearance: thin width, accessible neutral stroke thumb,
 * and transparent track. Forced colors use the browser's automatic colors.
 * Requires scoped theme variables and browser scrollbar-width/color support.
 * Adds no overflow, geometry, gutter, overscroll, smooth behavior, or WebKit rules.
 * Verify thumb contrast against the actual underlying surface.
 * @example sx(overflow.vertical.auto, scrollbar.fluent)
 */
export declare const fluent: SxBaseDescriptor;
//# sourceMappingURL=scrollbar.d.ts.map