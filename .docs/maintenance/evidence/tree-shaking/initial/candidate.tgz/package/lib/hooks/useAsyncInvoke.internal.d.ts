/**
 * Result type for useAsyncInvoke hook
 * @internal
 */
export interface AsyncInvokeResult<TClient> {
    /**
     * Invoke async operation with automatic state management.
     * Tracks loading state and captures errors automatically.
     *
     * @param fn - Function that receives the client and returns a promise
     * @returns Promise with the result
     */
    readonly invoke: <T>(fn: (client: TClient) => Promise<T>) => Promise<T>;
    /**
     * Loading state - true during invoke() calls.
     * Does not track direct client usage.
     */
    readonly isLoading: boolean;
    /**
     * Error from the most recently started invoke() call.
     * Older completions do not replace it; each new call clears it.
     * Does not capture errors from direct client usage.
     */
    readonly error: Error | undefined;
    /** Clear the current error */
    readonly clearError: () => void;
}
/**
 * Internal hook for async invocation with state management.
 *
 * @internal
 *
 * Provides a consistent pattern for:
 * - Loading state tracking during async operations
 * - Error capture and management
 * - Type-safe client invocation
 *
 * Used by HTTP client hooks (HttpClient, SPHttpClient, MSGraphClient, AadHttpClient)
 * to reduce code duplication while maintaining consistent behavior.
 *
 * @template TClient - The client type (HttpClient, SPHttpClient, MSGraphClientV3, AadHttpClient)
 * @param client - The client instance (can be undefined for async init scenarios)
 * @param notReadyError - Error message when client is undefined (default: 'Client not initialized')
 * @returns AsyncInvokeResult with invoke function, isLoading, error, and clearError
 *
 * @example
 * ```typescript
 * // Inside a hook implementation
 * const client = useMemo(() => consume<HttpClient>(HttpClient.serviceKey), [consume]);
 * const { invoke, isLoading, error, clearError } = useAsyncInvoke(
 *   client,
 *   'HttpClient not initialized. Check SPFx context.'
 * );
 * ```
 *
 * @internal
 */
export declare function useAsyncInvoke<TClient>(client: TClient | undefined, notReadyError?: string): AsyncInvokeResult<TClient>;
//# sourceMappingURL=useAsyncInvoke.internal.d.ts.map