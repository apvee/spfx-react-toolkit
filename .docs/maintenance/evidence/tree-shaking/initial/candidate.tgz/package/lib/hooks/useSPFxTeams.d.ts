/**
 * Teams theme type
 */
export type TeamsTheme = 'default' | 'dark' | 'highContrast';
/**
 * Return type for useSPFxTeams hook
 */
export interface SPFxTeamsInfo {
    /** Whether Teams context is supported/available */
    readonly supported: boolean;
    /** Teams context object (if available) */
    readonly context: unknown | undefined;
    /** Current Teams theme */
    readonly theme: TeamsTheme | undefined;
}
/**
 * Hook for Microsoft Teams context integration
 *
 * Provides access to Microsoft Teams context when SPFx component
 * is running in Teams environment.
 *
 * Automatically initializes Teams SDK (supports both v1 and v2 APIs)
 * and provides:
 * - Teams context (team, channel, user info, etc.)
 * - Teams theme (default, dark, high contrast)
 * - Supported flag
 *
 * The initialization happens asynchronously on first mount.
 *
 * Useful for:
 * - Teams-specific features
 * - Theme synchronization
 * - User context access
 * - Channel/team information
 * - Teams app integration
 *
 * @returns Teams context information
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { supported, context, theme } = useSPFxTeams();
 *
 *   if (!supported) {
 *     return <div>Not in Teams</div>;
 *   }
 *
 *   const teamsContext = context as {
 *     user?: { id: string };
 *     team?: { displayName: string };
 *   };
 *
 *   return (
 *     <div className={`teams-theme-${theme}`}>
 *       <p>Team: {teamsContext.team?.displayName}</p>
 *       <p>Theme: {theme}</p>
 *     </div>
 *   );
 * }
 * ```
 */
export declare function useSPFxTeams(): SPFxTeamsInfo;
//# sourceMappingURL=useSPFxTeams.d.ts.map