import { SxBaseDescriptor } from './types';
/** Sets flexGrow to 1 on a flex item.
 * @example sx(flexItem.grow)
 */
export declare const grow: SxBaseDescriptor;
/** Sets flexGrow to 0 on a flex item.
 * @example sx(flexItem.noGrow)
 */
export declare const noGrow: SxBaseDescriptor;
/** Sets flexShrink to 1 on a flex item.
 * @example sx(flexItem.shrink)
 */
export declare const shrink: SxBaseDescriptor;
/** Sets flexShrink to 0 on a flex item.
 * @example sx(flexItem.noShrink)
 */
export declare const noShrink: SxBaseDescriptor;
//# sourceMappingURL=flex-item.d.ts.map