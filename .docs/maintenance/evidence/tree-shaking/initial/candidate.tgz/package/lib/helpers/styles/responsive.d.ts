import { SxBaseDescriptor, SxStateDescriptor, SxResponsiveDescriptor } from './types';
/** Applies descriptors at the nearest ancestor named apvee-sx at inline-size >= 480px.
 * @param inputs Base or state descriptors; nested queries and class strings are unsupported.
 * @returns Immutable container query descriptor.
 * @example responsive.small(hover(foreground.subtle))
 */
export declare function small(...inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[]): SxResponsiveDescriptor;
/** Applies descriptors at the nearest ancestor named apvee-sx at inline-size >= 640px.
 * @param inputs Base or state descriptors; nested queries and class strings are unsupported.
 * @returns Immutable container query descriptor.
 * @example responsive.medium(hover(foreground.subtle))
 */
export declare function medium(...inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[]): SxResponsiveDescriptor;
/** Applies descriptors at the nearest ancestor named apvee-sx at inline-size >= 1024px.
 * @param inputs Base or state descriptors; nested queries and class strings are unsupported.
 * @returns Immutable container query descriptor.
 * @example responsive.large(hover(foreground.subtle))
 */
export declare function large(...inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[]): SxResponsiveDescriptor;
//# sourceMappingURL=responsive.d.ts.map