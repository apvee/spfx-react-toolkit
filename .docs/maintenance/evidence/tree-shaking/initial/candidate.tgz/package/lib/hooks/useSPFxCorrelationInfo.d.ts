/**
 * Return type for useSPFxCorrelationInfo hook
 */
export interface SPFxCorrelationInfo {
    /** Correlation ID for tracking requests across services */
    readonly correlationId: string | undefined;
    /** Azure AD Tenant ID */
    readonly tenantId: string | undefined;
}
/**
 * Hook for correlation and tenant ID extraction
 *
 * Provides diagnostic IDs for tracking and monitoring:
 * - Correlation ID: Tracks requests across SPFx → SharePoint → Microsoft Graph
 * - Tenant ID: Azure AD tenant identifier
 *
 * These IDs are essential for:
 * - Distributed tracing
 * - Log correlation
 * - Support tickets
 * - Diagnostic troubleshooting
 * - Security auditing
 *
 * Useful for:
 * - Structured logging
 * - Error tracking (Application Insights, etc.)
 * - Support requests
 * - Performance monitoring
 *
 * @returns Correlation and tenant identifiers
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { correlationId, tenantId } = useSPFxCorrelationInfo();
 *
 *   const logError = (error: Error) => {
 *     console.error('Error occurred', {
 *       message: error.message,
 *       correlationId,
 *       tenantId,
 *       timestamp: new Date().toISOString()
 *     });
 *   };
 *
 *   return <div>Tenant: {tenantId}</div>;
 * }
 * ```
 */
export declare function useSPFxCorrelationInfo(): SPFxCorrelationInfo;
//# sourceMappingURL=useSPFxCorrelationInfo.d.ts.map