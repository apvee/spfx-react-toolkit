import type { IReadonlyTheme } from '@microsoft/sp-component-base';
import type { DisplayMode } from '@microsoft/sp-core-library';
import type { ContainerSize } from './types';
export type SPFxRuntimeTeamsTheme = 'default' | 'dark' | 'highContrast';
export interface SPFxRuntimeTeamsState {
    readonly supported: boolean;
    readonly context?: unknown;
    readonly theme?: SPFxRuntimeTeamsTheme;
    readonly initialized: boolean;
}
export interface SPFxRuntimeState {
    readonly theme: IReadonlyTheme | undefined;
    readonly displayMode: DisplayMode | undefined;
    readonly properties: unknown;
    readonly containerEl: HTMLElement | undefined;
    readonly containerSize: ContainerSize | undefined;
    readonly teams: SPFxRuntimeTeamsState;
}
export type SPFxRuntimeListener = () => void;
export type SPFxRuntimeUpdater = Partial<SPFxRuntimeState> | ((previous: SPFxRuntimeState) => SPFxRuntimeState);
export interface SPFxRuntimeStore {
    getState(): SPFxRuntimeState;
    setState(updater: SPFxRuntimeUpdater): void;
    subscribe(listener: SPFxRuntimeListener): () => void;
}
export declare function createDefaultSPFxRuntimeState(): SPFxRuntimeState;
export declare function createSPFxRuntimeStore(initialState?: Partial<SPFxRuntimeState>): SPFxRuntimeStore;
//# sourceMappingURL=runtime-store.internal.d.ts.map