import { type SPFxApiPermissionCheckResult, type SPFxApiPermissionPrecheckConfig } from '../helpers/spfx-api-permission-precheck.helpers';
export interface SPFxAadTokenProviderLike {
    getToken(resourceEndpoint: string, options?: {
        readonly useCachedToken?: boolean;
        readonly claims?: string;
    }): Promise<string>;
}
export interface SPFxApiPermissionPrecheckServiceOptions {
    readonly useCachedToken?: boolean;
    readonly validateAudience?: boolean;
    readonly timeoutMs?: number;
    readonly sequentialResourceAcquisition?: boolean;
}
export interface SPFxApiPermissionPrecheckService {
    check(config: SPFxApiPermissionPrecheckConfig, options?: SPFxApiPermissionPrecheckServiceOptions): Promise<readonly SPFxApiPermissionCheckResult[]>;
}
export declare function createSPFxApiPermissionPrecheckService(tokenProvider: SPFxAadTokenProviderLike): SPFxApiPermissionPrecheckService;
//# sourceMappingURL=spfx-api-permission-precheck.service.d.ts.map