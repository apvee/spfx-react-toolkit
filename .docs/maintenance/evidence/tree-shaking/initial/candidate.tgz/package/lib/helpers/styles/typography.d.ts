import { SxBaseDescriptor } from './types';
/** Official Fluent body1 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.body1)
 */
export declare const body1: SxBaseDescriptor;
/** Official Fluent body1Strong recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.body1Strong)
 */
export declare const body1Strong: SxBaseDescriptor;
/** Official Fluent body1Stronger recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.body1Stronger)
 */
export declare const body1Stronger: SxBaseDescriptor;
/** Official Fluent body2 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.body2)
 */
export declare const body2: SxBaseDescriptor;
/** Official Fluent caption1 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.caption1)
 */
export declare const caption1: SxBaseDescriptor;
/** Official Fluent caption1Strong recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.caption1Strong)
 */
export declare const caption1Strong: SxBaseDescriptor;
/** Official Fluent caption1Stronger recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.caption1Stronger)
 */
export declare const caption1Stronger: SxBaseDescriptor;
/** Official Fluent caption2 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.caption2)
 */
export declare const caption2: SxBaseDescriptor;
/** Official Fluent caption2Strong recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.caption2Strong)
 */
export declare const caption2Strong: SxBaseDescriptor;
/** Official Fluent subtitle1 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.subtitle1)
 */
export declare const subtitle1: SxBaseDescriptor;
/** Official Fluent subtitle2 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.subtitle2)
 */
export declare const subtitle2: SxBaseDescriptor;
/** Official Fluent subtitle2Stronger recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.subtitle2Stronger)
 */
export declare const subtitle2Stronger: SxBaseDescriptor;
/** Official Fluent title1 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.title1)
 */
export declare const title1: SxBaseDescriptor;
/** Official Fluent title2 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.title2)
 */
export declare const title2: SxBaseDescriptor;
/** Official Fluent title3 recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.title3)
 */
export declare const title3: SxBaseDescriptor;
/** Official Fluent largeTitle recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.largeTitle)
 */
export declare const largeTitle: SxBaseDescriptor;
/** Official Fluent display recipe: fontFamily, fontSize, fontWeight, and lineHeight.
 * Preserves theme variables and inherited color; does not assign HTML semantics.
 * @example sx(typography.display)
 */
export declare const display: SxBaseDescriptor;
//# sourceMappingURL=typography.d.ts.map