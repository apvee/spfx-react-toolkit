import * as React from 'react';
import type { IReadonlyTheme } from '@microsoft/sp-component-base';
import type { DisplayMode } from '@microsoft/sp-core-library';
import type { ContainerSize } from './types';
import type { SPFxRuntimeState, SPFxRuntimeStore, SPFxRuntimeTeamsState } from './runtime-store.internal';
export declare const SPFxRuntimeStoreContext: React.Context<SPFxRuntimeStore | undefined>;
export declare function useSPFxRuntimeStore(): SPFxRuntimeStore;
export declare function useSPFxRuntimeSelector<T>(selector: (state: SPFxRuntimeState) => T, isEqual?: (previous: T, next: T) => boolean): T;
export interface SPFxRuntimeActions {
    readonly setTheme: (theme: IReadonlyTheme | undefined) => void;
    readonly setDisplayMode: (displayMode: DisplayMode | undefined) => void;
    readonly setProperties: (updater: unknown | ((previous: unknown) => unknown)) => void;
    readonly setContainerElement: (element: HTMLElement | undefined) => void;
    readonly setContainerSize: (size: ContainerSize | undefined) => void;
    readonly setTeamsState: (teams: SPFxRuntimeTeamsState) => void;
}
export declare function createSPFxRuntimeActions(store: SPFxRuntimeStore): SPFxRuntimeActions;
export declare function useSPFxRuntimeActions(): SPFxRuntimeActions;
//# sourceMappingURL=state.internal.d.ts.map