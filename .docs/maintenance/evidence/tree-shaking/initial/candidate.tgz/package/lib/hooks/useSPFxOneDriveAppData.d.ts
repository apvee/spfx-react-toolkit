/**
 * Return type for useSPFxOneDriveAppData hook
 */
export interface SPFxOneDriveAppDataResult<T> {
    /**
     * The loaded data from OneDrive.
     * Undefined if not loaded yet or on error.
     */
    readonly data: T | undefined;
    /**
     * Loading state for read operations.
     * True during initial load or manual load() calls.
     */
    readonly isLoading: boolean;
    /**
     * Last error from read operations.
     * Cleared on successful load or write.
     */
    readonly error: Error | undefined;
    /**
     * True if the file does not exist in OneDrive (404 / itemNotFound).
     * In the legacy signature this is treated as a non-error.
     */
    readonly isNotFound: boolean;
    /**
     * Loading state for write operations.
     * True during write() calls.
     */
    readonly isWriting: boolean;
    /**
     * Last error from write operations.
     * Cleared on successful write or load.
     */
    readonly writeError: Error | undefined;
    /**
     * Manually load/reload the file from OneDrive.
     * Updates data, isLoading, and error states.
     *
     * @returns Promise that resolves when load completes
     *
     * @example
     * ```tsx
     * const { data, load } = useSPFxOneDriveAppData<Config>('config.json', undefined, false);
     *
     * // Load on button click
     * <button onClick={load}>Refresh</button>
     * ```
     */
    readonly load: () => Promise<void>;
    /**
     * Write data to OneDrive file.
     * Creates file if it doesn't exist, updates if it does.
     * Updates isWriting and writeError states.
     *
     * @param content - Data to write (will be JSON.stringify'd)
     * @returns Promise that resolves when write completes
     *
     * @example
     * ```tsx
     * const { write, isWriting } = useSPFxOneDriveAppData<Config>('config.json');
     *
     * const handleSave = async () => {
     *   await write({ theme: 'dark', language: 'en' });
     * };
     * ```
     */
    readonly write: (content: T) => Promise<void>;
    /**
     * Computed state: true if data is loaded successfully.
     * Equivalent to: !isLoading && !error && data !== undefined
     *
     * Useful for conditional rendering:
     * ```tsx
     * if (!isReady) return <Spinner />;
     * return <div>{data.title}</div>;
     * ```
     */
    readonly isReady: boolean;
}
/**
 * Optional configuration for useSPFxOneDriveAppData.
 */
export interface SPFxOneDriveAppDataOptions<T> {
    /** Optional folder/namespace identifier for file organization. */
    folder?: string;
    /** Whether to automatically load file on mount. Default: true */
    autoFetch?: boolean;
    /**
     * Default value to use when the file is missing (404).
     * If provided, load() will set data to this value and will not set error.
     */
    defaultValue?: T;
    /**
     * If true, when the file is missing (404) and defaultValue is provided,
     * the hook will attempt to create the file by writing defaultValue.
     */
    createIfMissing?: boolean;
}
/**
 * Hook to manage JSON files in user's OneDrive approot folder
 *
 * Provides unified read/write operations for JSON data stored in OneDrive's special
 * approot folder (accessible per-app, user-scoped storage).
 *
 * Features:
 * - Automatic JSON serialization/deserialization
 * - Separate loading states for read/write operations
 * - Optional auto-fetch on mount
 * - Folder/namespace support for file organization
 * - Type-safe with TypeScript generics
 * - Memory leak safe with mounted state tracking
 * - Error handling for both read and write operations
 *
 * Requirements:
 * - Microsoft Graph permissions: Files.ReadWrite or Files.ReadWrite.AppFolder
 * - User must be authenticated
 *
 * @param fileName - Name of the JSON file (e.g., 'config.json', 'settings.json')
 * @param folder - Optional folder/namespace identifier for file organization.
 *                 Will be sanitized to prevent path traversal.
 *                 Examples: 'my-app', instanceId (GUID), 'config-v2'
 * @param autoFetch - Whether to automatically load file on mount. Default: true
 *
 * @returns Object with data, loading states, error states, and read/write functions
 *
 * @example Basic usage - auto-fetch from root
 * ```tsx
 * import type { MyConfig } from './types';
 *
 * function ConfigPanel() {
 *   const { data, isLoading, error, write, isWriting } =
 *     useSPFxOneDriveAppData<MyConfig>('config.json');
 *
 *   if (isLoading) return <Spinner label="Loading configuration..." />;
 *   if (error) return <MessageBar messageBarType={MessageBarType.error}>
 *     Failed to load: {error.message}
 *   </MessageBar>;
 *
 *   const handleSave = async (newConfig: MyConfig) => {
 *     try {
 *       await write(newConfig);
 *       console.log('Saved successfully!');
 *     } catch (err) {
 *       console.error('Save failed:', err);
 *     }
 *   };
 *
 *   return (
 *     <div>
 *       <TextField
 *         value={data?.title}
 *         onChange={(_, val) => handleSave({ ...data, title: val })}
 *         disabled={isWriting}
 *       />
 *       {isWriting && <Spinner label="Saving..." />}
 *     </div>
 *   );
 * }
 * ```
 *
 * @example With folder namespace
 * ```tsx
 * // Store files in a dedicated folder
 * const { data, write } = useSPFxOneDriveAppData<State>(
 *   'state.json',
 *   'my-app-v2'  // Files stored in approot:/my-app-v2/state.json
 * );
 * ```
 *
 * @example Per-instance storage (multi-instance support)
 * ```tsx
 * // Each WebPart instance has its own data
 * const { id } = useSPFxInstanceInfo();
 * const { data, write } = useSPFxOneDriveAppData<Settings>(
 *   'settings.json',
 *   id  // Files stored in approot:/abc-123-guid/settings.json
 * );
 * ```
 *
 * @example Lazy loading (manual load)
 * ```tsx
 * const { data, load, isLoading, write } = useSPFxOneDriveAppData<Cache>(
 *   'cache.json',
 *   'my-app',
 *   false  // Don't auto-fetch
 * );
 *
 * return (
 *   <div>
 *     <button onClick={load} disabled={isLoading}>
 *       {isLoading ? 'Loading...' : 'Load Cache'}
 *     </button>
 *     {data && <pre>{JSON.stringify(data, null, 2)}</pre>}
 *   </div>
 * );
 * ```
 *
 * @example Multiple files in same namespace
 * ```tsx
 * function MyApp() {
 *   const config = useSPFxOneDriveAppData<Config>('config.json', 'myapp');
 *   const state = useSPFxOneDriveAppData<State>('state.json', 'myapp');
 *   const cache = useSPFxOneDriveAppData<Cache>('cache.json', 'myapp');
 *
 *   // All files stored in approot:/myapp/
 *   // Easy to manage and clean up as a group
 * }
 * ```
 *
 * @example Error handling and retry
 * ```tsx
 * function DataManager() {
 *   const { data, error, load, writeError, write, isReady } =
 *     useSPFxOneDriveAppData<MyData>('data.json');
 *
 *   if (error) {
 *     return (
 *       <MessageBar
 *         messageBarType={MessageBarType.error}
 *         actions={<button onClick={load}>Retry</button>}
 *       >
 *         Load failed: {error.message}
 *       </MessageBar>
 *     );
 *   }
 *
 *   if (writeError) {
 *     return (
 *       <MessageBar messageBarType={MessageBarType.warning}>
 *         Save failed: {writeError.message}
 *       </MessageBar>
 *     );
 *   }
 *
 *   if (!isReady) return <Spinner />;
 *
 *   return <DataDisplay data={data} onSave={write} />;
 * }
 * ```
 *
 * @example CRUD-like operations
 * ```tsx
 * interface TodoList {
 *   items: Array<{ id: string; text: string; done: boolean }>;
 * }
 *
 * function TodoApp() {
 *   const { data, write, isLoading, isWriting } =
 *     useSPFxOneDriveAppData<TodoList>('todos.json', 'todo-app');
 *
 *   const addTodo = async (text: string) => {
 *     const newItem = { id: crypto.randomUUID(), text, done: false };
 *     await write({
 *       items: [...(data?.items ?? []), newItem]
 *     });
 *   };
 *
 *   const toggleTodo = async (id: string) => {
 *     await write({
 *       items: data?.items.map(item =>
 *         item.id === id ? { ...item, done: !item.done } : item
 *       ) ?? []
 *     });
 *   };
 *
 *   const deleteTodo = async (id: string) => {
 *     await write({
 *       items: data?.items.filter(item => item.id !== id) ?? []
 *     });
 *   };
 *
 *   if (isLoading) return <Spinner />;
 *
 *   return (
 *     <div>
 *       <TodoList
 *         items={data?.items ?? []}
 *         onToggle={toggleTodo}
 *         onDelete={deleteTodo}
 *       />
 *       <AddTodoForm onAdd={addTodo} disabled={isWriting} />
 *     </div>
 *   );
 * }
 * ```
 */
export declare function useSPFxOneDriveAppData<T = unknown>(fileName: string, options?: SPFxOneDriveAppDataOptions<T>): SPFxOneDriveAppDataResult<T>;
//# sourceMappingURL=useSPFxOneDriveAppData.d.ts.map