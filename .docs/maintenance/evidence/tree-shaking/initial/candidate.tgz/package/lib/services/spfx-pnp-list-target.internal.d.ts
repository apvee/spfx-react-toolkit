import type { SPFI } from '@pnp/sp';
import type { IList } from '@pnp/sp/lists';
interface ListTargetSnapshot {
    readonly kind: string | undefined;
    readonly value: string | undefined;
}
/** Capture only primitive selector fields; validation belongs to async operations. */
export declare function snapshotListTarget(target: unknown): ListTargetSnapshot;
/** Resolve against the actual client that will execute or queue the operation. */
export declare function resolveListTarget(sp: SPFI, target: ListTargetSnapshot): IList;
export {};
//# sourceMappingURL=spfx-pnp-list-target.internal.d.ts.map