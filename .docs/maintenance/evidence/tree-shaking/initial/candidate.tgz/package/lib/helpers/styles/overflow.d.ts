import { SxBaseDescriptor } from './types';
/** Controls only the horizontal overflow axis. */
export * as horizontal from './overflow-horizontal';
/** Controls only the vertical overflow axis. */
export * as vertical from './overflow-vertical';
/** Sets both overflow axes to visible; adds no dimensions or scrollbar appearance.
 * @example sx(overflow.visible)
 */
export declare const visible: SxBaseDescriptor;
/** Sets both overflow axes to hidden; adds no dimensions or scrollbar appearance.
 * @example sx(overflow.hidden)
 */
export declare const hidden: SxBaseDescriptor;
/** Sets both overflow axes to auto; adds no dimensions or scrollbar appearance.
 * @example sx(overflow.auto)
 */
export declare const auto: SxBaseDescriptor;
//# sourceMappingURL=overflow.d.ts.map