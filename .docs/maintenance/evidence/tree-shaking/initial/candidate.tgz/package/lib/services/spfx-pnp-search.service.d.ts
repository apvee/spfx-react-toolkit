import type { SPFI } from '@pnp/sp';
import '@pnp/sp/search';
import type { ISearchBuilder } from '@pnp/sp/search';
export type SPFxPnPSearchQueryBuilder = (builder: ISearchBuilder) => ISearchBuilder;
export interface SPFxPnPSearchOptions {
    pageSize?: number;
    selectProperties?: string[];
    refiners?: string;
}
export interface SPFxPnPSearchRequestOptions {
    pageSize?: number;
    startRow?: number;
    refinementFilters?: Map<string, string[]>;
}
export interface SPFxPnPSearchResult<T = Record<string, string>> {
    id: string;
    data: T;
    raw: unknown;
    rank?: number;
}
export interface SPFxPnPSearchRefiner {
    name: string;
    entries: Array<{
        value: string;
        count: number;
        token: string;
    }>;
}
export interface SPFxPnPSearchResponse<T = Record<string, string>> {
    results: SPFxPnPSearchResult<T>[];
    totalResults: number;
    refiners: SPFxPnPSearchRefiner[];
}
export interface SPFxPnPSearchService<T = Record<string, string>> {
    search: (query: string | SPFxPnPSearchQueryBuilder, options?: SPFxPnPSearchRequestOptions) => Promise<SPFxPnPSearchResponse<T>>;
    suggest: (queryText: string) => Promise<string[]>;
}
export declare function createSPFxPnPSearchService<T = Record<string, string>>(sp: SPFI, defaultOptions?: SPFxPnPSearchOptions): SPFxPnPSearchService<T>;
//# sourceMappingURL=spfx-pnp-search.service.d.ts.map