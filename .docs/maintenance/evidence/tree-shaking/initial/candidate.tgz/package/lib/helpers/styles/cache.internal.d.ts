import { makeStyles } from '@griffel/core';
import type { GriffelRenderer } from '@griffel/core';
export type SxStyleFactory = ReturnType<typeof makeStyles<'root'>>;
export interface SxRendererCache {
    readonly bindings: Map<string, SxStyleFactory>;
    readonly assignments: Map<string, SxStyleFactory>;
}
export declare function getSxRendererCache(renderer: GriffelRenderer): SxRendererCache;
//# sourceMappingURL=cache.internal.d.ts.map