import type { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import type { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
import type { BaseListViewCommandSet, BaseFieldCustomizer } from '@microsoft/sp-listview-extensibility';
import type { SPFxComponent, HostKind } from '../core/types';
/**
 * Type guard: Check if instance is a WebPart
 *
 * Uses duck typing (structural typing) to detect WebPart instances
 * by checking for WebPart-specific properties: displayMode, domElement, render, context, properties.
 *
 * @template TProps - WebPart properties type
 * @param instance - SPFx component instance to check
 * @returns True if instance is a BaseClientSideWebPart, narrowing the type
 *
 * @example
 * ```typescript
 * if (isWebPart(instance)) {
 *   // instance is now typed as BaseClientSideWebPart<TProps>
 *   console.log(instance.displayMode);
 * }
 * ```
 *
 * @internal
 */
export declare function isWebPart<TProps extends {} = {}>(instance: unknown): instance is BaseClientSideWebPart<TProps>;
/**
 * Type guard: Check if instance is an ApplicationCustomizer
 *
 * Uses duck typing (structural typing) to detect ApplicationCustomizer instances
 * by checking for placeholderProvider in context and absence of displayMode.
 *
 * @template TProps - ApplicationCustomizer properties type
 * @param instance - SPFx component instance to check
 * @returns True if instance is a BaseApplicationCustomizer, narrowing the type
 *
 * @example
 * ```typescript
 * if (isApplicationCustomizer(instance)) {
 *   // instance is now typed as BaseApplicationCustomizer<TProps>
 *   console.log(instance.context.placeholderProvider);
 * }
 * ```
 *
 * @internal
 */
export declare function isApplicationCustomizer<TProps extends {} = {}>(instance: unknown): instance is BaseApplicationCustomizer<TProps>;
/**
 * Type guard: Check if instance is a ListViewCommandSet
 *
 * Uses duck typing (structural typing) to detect ListViewCommandSet instances
 * by checking for onExecute and tryGetCommand methods.
 *
 * @template TProps - ListViewCommandSet properties type
 * @param instance - SPFx component instance to check
 * @returns True if instance is a BaseListViewCommandSet, narrowing the type
 *
 * @example
 * ```typescript
 * if (isListViewCommandSet(instance)) {
 *   // instance is now typed as BaseListViewCommandSet<TProps>
 *   instance.tryGetCommand('COMMAND_ID');
 * }
 * ```
 *
 * @internal
 */
export declare function isListViewCommandSet<TProps extends {} = {}>(instance: unknown): instance is BaseListViewCommandSet<TProps>;
/**
 * Type guard: Check if instance is a FieldCustomizer
 *
 * Uses duck typing (structural typing) to detect FieldCustomizer instances
 * by checking for field in context and onRenderCell method.
 *
 * @template TProps - FieldCustomizer properties type
 * @param instance - SPFx component instance to check
 * @returns True if instance is a BaseFieldCustomizer, narrowing the type
 *
 * @example
 * ```typescript
 * if (isFieldCustomizer(instance)) {
 *   // instance is now typed as BaseFieldCustomizer<TProps>
 *   console.log(instance.context.field);
 * }
 * ```
 *
 * @internal
 */
export declare function isFieldCustomizer<TProps extends {} = {}>(instance: unknown): instance is BaseFieldCustomizer<TProps>;
/**
 * Detect the kind of SPFx component from an instance
 *
 * Checks the instance against all known SPFx component types and returns
 * the corresponding HostKind discriminator.
 *
 * @template TProps - SPFx component properties type
 * @param instance - SPFx component instance to detect
 * @returns HostKind ('WebPart' | 'AppCustomizer' | 'CommandSet' | 'FieldCustomizer')
 * @throws Error if unable to detect component type
 *
 * @example
 * ```typescript
 * const kind = detectComponentKind(this); // 'WebPart'
 * ```
 *
 * @internal
 */
export declare function detectComponentKind<TProps extends {} = {}>(instance: SPFxComponent<TProps>): HostKind;
//# sourceMappingURL=type-guards.internal.d.ts.map