export declare function collectRejectedReasons<T>(settled: PromiseSettledResult<T>[]): unknown[];
export declare function collectCreatedIds<T extends {
    data: {
        Id: number;
    };
}>(settled: PromiseSettledResult<T>[]): {
    ids: number[];
    errors: unknown[];
};
export declare function createBatchError(action: 'create' | 'update' | 'delete', failed: number, total: number): Error;
//# sourceMappingURL=useSPFxPnPList.batch.internal.d.ts.map