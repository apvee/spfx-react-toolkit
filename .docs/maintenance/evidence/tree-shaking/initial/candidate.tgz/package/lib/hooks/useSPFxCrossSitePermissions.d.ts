import { SPPermission } from '@microsoft/sp-page-context';
/**
 * Options for cross-site permissions retrieval
 */
export interface SPFxCrossSitePermissionsOptions {
    /**
     * Optional web URL within the site (e.g., '/sites/mysite/subweb')
     */
    webUrl?: string;
    /**
     * Optional list ID to retrieve list-level permissions
     */
    listId?: string;
}
/**
 * Information about cross-site permissions
 */
export interface SPFxCrossSitePermissionsInfo {
    /**
     * Site-level permissions
     */
    sitePermissions?: SPPermission;
    /**
     * Web-level permissions
     */
    webPermissions?: SPPermission;
    /**
     * List-level permissions (if listId provided)
     */
    listPermissions?: SPPermission;
    /**
     * Check if user has specific web permission
     */
    hasWebPermission: (permission: SPPermission) => boolean;
    /**
     * Check if user has specific site permission
     */
    hasSitePermission: (permission: SPPermission) => boolean;
    /**
     * Check if user has specific list permission
     */
    hasListPermission: (permission: SPPermission) => boolean;
    /**
     * Loading state
     */
    isLoading: boolean;
    /**
     * Error state
     */
    error?: Error;
}
/**
 * Hook to retrieve permissions for a different site/web/list
 *
 * @param siteUrl - The target site URL (optional - no fetch if undefined/empty)
 * @param options - Optional configuration (webUrl, listId)
 * @returns Permissions information with helper methods
 *
 * @example
 * ```tsx
 * // Lazy loading - no fetch until URL is set
 * const [targetUrl, setTargetUrl] = useState<string | undefined>(undefined);
 * const {
 *   sitePermissions,
 *   webPermissions,
 *   hasWebPermission,
 *   isLoading
 * } = useSPFxCrossSitePermissions(targetUrl, {
 *   webUrl: 'https://contoso.sharepoint.com/sites/target/subweb'
 * });
 *
 * // Set URL when ready - triggers fetch
 * setTargetUrl('https://contoso.sharepoint.com/sites/target');
 *
 * if (!isLoading && hasWebPermission(SPPermission.addListItems)) {
 *   // User can add items
 * }
 * ```
 */
export declare function useSPFxCrossSitePermissions(siteUrl?: string, options?: SPFxCrossSitePermissionsOptions): SPFxCrossSitePermissionsInfo;
//# sourceMappingURL=useSPFxCrossSitePermissions.d.ts.map