import { type SPFxApiPermissionCheckResult, type SPFxApiPermissionConfigurationState, type SPFxApiPermissionPrecheckConfig, type SPFxApiPermissionPrecheckMode, type SPFxApiPermissionSummary } from '../helpers/spfx-api-permission-precheck.helpers';
export interface SPFxApiPermissionPrecheckOptions {
    readonly autoCheck?: boolean;
    readonly mode?: SPFxApiPermissionPrecheckMode;
    readonly useCachedToken?: boolean;
    readonly validateAudience?: boolean;
    readonly timeoutMs?: number;
}
export interface SPFxApiPermissionPrecheckResult {
    readonly isChecking: boolean;
    readonly isConfigured: boolean;
    readonly configurationState: SPFxApiPermissionConfigurationState;
    readonly available: readonly SPFxApiPermissionSummary[];
    readonly missing: readonly SPFxApiPermissionSummary[];
    readonly warnings: readonly SPFxApiPermissionSummary[];
    readonly unknown: readonly SPFxApiPermissionSummary[];
    readonly results: readonly SPFxApiPermissionCheckResult[];
    readonly tokenProviderError: Error | undefined;
    readonly check: () => Promise<readonly SPFxApiPermissionCheckResult[]>;
    readonly retry: () => Promise<readonly SPFxApiPermissionCheckResult[]>;
    readonly retryWithoutCache: () => Promise<readonly SPFxApiPermissionCheckResult[]>;
}
export declare function useSPFxApiPermissionPrecheck(config: SPFxApiPermissionPrecheckConfig, options?: SPFxApiPermissionPrecheckOptions): SPFxApiPermissionPrecheckResult;
//# sourceMappingURL=useSPFxApiPermissionPrecheck.d.ts.map