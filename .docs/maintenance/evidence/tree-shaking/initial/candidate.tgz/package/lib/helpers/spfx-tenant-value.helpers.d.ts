/**
 * Escapes a string value for use in OData filter expressions.
 *
 * @param value - Raw string value
 * @returns Escaped string safe for OData filters
 */
export declare function escapeODataValue(value: string): string;
/**
 * Serializes a tenant-scoped value for SharePoint string storage.
 *
 * @param value - Value to serialize
 * @returns Serialized string representation
 */
export declare function serializeTenantValue(value: unknown): string;
/**
 * Deserializes a tenant-scoped SharePoint string value.
 *
 * @param rawValue - Stored string value
 * @returns Parsed value, or the raw string when JSON parsing fails
 */
export declare function deserializeTenantValue<T>(rawValue: string): T;
//# sourceMappingURL=spfx-tenant-value.helpers.d.ts.map