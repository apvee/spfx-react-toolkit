import type { IReadonlyTheme } from '@microsoft/sp-component-base';
import type { Theme } from '@fluentui/react-theme';
/**
 * Converts an SPFx v8 theme to a Fluent UI 9 theme.
 *
 * @param spfxTheme - SPFx theme, or undefined for the default web light theme
 * @returns Fluent UI 9 theme
 */
export declare function createFluent9ThemeFromSPFxTheme(spfxTheme: IReadonlyTheme | undefined): Theme;
/**
 * Maps a Teams theme name to the matching Fluent UI 9 Teams theme.
 *
 * @param teamsThemeName - Teams theme name
 * @returns Fluent UI 9 Teams theme
 */
export declare function getTeamsFluentTheme(teamsThemeName: string | undefined): Theme;
//# sourceMappingURL=spfx-theme.helpers.d.ts.map