import type { MSGraphClientV3 } from '@microsoft/sp-http';
export type SPFxUserPhotoServiceSize = '48x48' | '64x64' | '96x96' | '120x120' | '240x240' | '360x360' | '432x432' | '504x504' | '648x648';
export interface SPFxUserPhotoServiceOptions {
    readonly userId?: string;
    readonly email?: string;
    readonly size?: SPFxUserPhotoServiceSize;
}
export interface SPFxUserPhotoService {
    getPhotoBlob: (options?: SPFxUserPhotoServiceOptions) => Promise<Blob>;
}
export declare function createSPFxUserPhotoService(graphClient: MSGraphClientV3): SPFxUserPhotoService;
//# sourceMappingURL=spfx-user-photo.service.d.ts.map