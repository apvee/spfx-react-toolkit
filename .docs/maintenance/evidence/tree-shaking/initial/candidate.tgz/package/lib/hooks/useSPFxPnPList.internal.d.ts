import type { PnPContextInfo } from './useSPFxPnPContext';
import type { SPFxPnPListInfo, UseSPFxPnPListOptions } from './useSPFxPnPList';
import type { SPFxPnPListSelector } from '../services/spfx-pnp-list.service';
/** Shared list hook lifecycle for title and explicit selector wrappers. */
export declare function useSPFxPnPListInternal<T = unknown>(listTarget: string | SPFxPnPListSelector, options?: UseSPFxPnPListOptions, pnpContext?: PnPContextInfo): SPFxPnPListInfo<T>;
//# sourceMappingURL=useSPFxPnPList.internal.d.ts.map