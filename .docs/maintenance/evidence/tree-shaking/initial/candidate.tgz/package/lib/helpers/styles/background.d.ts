import { SxBaseDescriptor } from './types';
/** Applies Fluent's colorNeutralBackground1 CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.canvas)
 */
export declare const canvas: SxBaseDescriptor;
/** Applies Fluent's colorNeutralBackground2 CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.alternative)
 */
export declare const alternative: SxBaseDescriptor;
/** Applies Fluent's colorSubtleBackground CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.subtle)
 */
export declare const subtle: SxBaseDescriptor;
/** Applies Fluent's colorTransparentBackground CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.transparent)
 */
export declare const transparent: SxBaseDescriptor;
/** Applies Fluent's colorBrandBackground CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.brand)
 */
export declare const brand: SxBaseDescriptor;
/** Applies Fluent's colorBrandBackground2 CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.brandTint)
 */
export declare const brandTint: SxBaseDescriptor;
/** Applies Fluent's colorNeutralBackgroundInverted CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.inverted)
 */
export declare const inverted: SxBaseDescriptor;
/** Applies Fluent's colorNeutralBackgroundDisabled CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(background.disabled)
 */
export declare const disabled: SxBaseDescriptor;
//# sourceMappingURL=background.d.ts.map