/**
 * Performance result type
 */
export interface SPFxPerfResult<T = unknown> {
    /** Measurement name */
    readonly name: string;
    /** Duration in milliseconds */
    readonly durationMs: number;
    /** Optional result from timed operation */
    readonly result?: T;
    /** SPFx instance ID */
    readonly instanceId: string;
    /** Host kind */
    readonly host: string;
    /** Correlation ID for tracking */
    readonly correlationId: string | undefined;
}
/**
 * Return type for useSPFxPerformance hook
 */
export interface SPFxPerformanceInfo {
    /** Create a performance mark */
    readonly mark: (name: string) => void;
    /** Measure duration between two marks */
    readonly measure: (name: string, startMark: string, endMark?: string) => SPFxPerfResult;
    /** Time an async operation */
    readonly time: <T>(name: string, fn: () => Promise<T> | T) => Promise<SPFxPerfResult<T>>;
}
/**
 * Hook for performance measurement and monitoring
 *
 * Provides access to the Performance API for measuring code execution time.
 *
 * Methods:
 * - mark(): Create named performance marks
 * - measure(): Calculate duration between marks
 * - time(): Wrap async operations with automatic timing
 *
 * All measurements include SPFx context (instanceId, correlationId) for
 * integration with logging and monitoring systems.
 *
 * Useful for:
 * - Performance profiling
 * - Identifying bottlenecks
 * - Monitoring real-world performance
 * - Integration with Application Insights
 * - Custom performance dashboards
 *
 * @returns Performance measurement methods
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { mark, measure, time } = useSPFxPerformance();
 *   const [data, setData] = useState(null);
 *
 *   const fetchData = async () => {
 *     const result = await time('fetch-data', async () => {
 *       const response = await fetch('/api/data');
 *       return response.json();
 *     });
 *
 *     console.log(`Fetch took ${result.durationMs}ms`);
 *     setData(result.result);
 *   };
 *
 *   return <button onClick={fetchData}>Load Data</button>;
 * }
 * ```
 */
export declare function useSPFxPerformance(): SPFxPerformanceInfo;
//# sourceMappingURL=useSPFxPerformance.d.ts.map