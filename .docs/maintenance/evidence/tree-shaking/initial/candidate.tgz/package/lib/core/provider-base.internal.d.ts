import * as React from 'react';
import type { SPFxProviderProps } from './types';
/**
 * SPFxProviderBase - Internal base provider with shared logic
 *
 * Creates an isolated runtime store for each instance, ensuring complete
 * state isolation between multiple SPFx components on the same page.
 *
 * The provider ensures SPFx ServiceScope is finished before rendering children,
 * guaranteeing that all services are available for consumption via dependency
 * injection in hooks. This prevents race conditions and ensures type-safe access
 * to SPFx services.
 *
 * DO NOT use directly - use type-specific providers instead:
 * - SPFxWebPartProvider
 * - SPFxApplicationCustomizerProvider
 * - SPFxListViewCommandSetProvider
 * - SPFxFieldCustomizerProvider
 *
 * @internal
 */
export declare function SPFxProviderBase<TProps extends {} = {}>(props: SPFxProviderProps<TProps>): React.ReactElement;
//# sourceMappingURL=provider-base.internal.d.ts.map