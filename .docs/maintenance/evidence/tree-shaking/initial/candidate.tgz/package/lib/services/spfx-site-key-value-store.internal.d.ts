import { SPHttpClient } from '@microsoft/sp-http';
import type { SPHttpClientResponse } from '@microsoft/sp-http';
interface SiteField {
    InternalName: string;
    FieldTypeKind: number;
    Indexed?: boolean;
    EnforceUniqueValues?: boolean;
}
export interface SiteStoreRow {
    Id: number;
    Title: string;
    Value: string;
    Description?: string;
}
export declare function normalizeSiteStoreUrl(url: string): string;
export declare function siteStoreListUrl(url: string): string;
export declare function readSiteStorePage(data: unknown): {
    rows: SiteStoreRow[];
    next?: string;
};
export declare function resolveSiteStorePageUrl(link: string, currentUrl: string, itemsUrl: string, seen: Set<string>): string;
export declare function siteStoreResponseError(response: SPHttpClientResponse, operation: string): Promise<Error>;
export declare function mayRecoverSiteStoreCreation(response: SPHttpClientResponse): boolean;
export declare function createSiteStoreSetup(spHttpClient: SPHttpClient): {
    exists: (url: string) => Promise<boolean>;
    probe: (url: string) => Promise<boolean>;
    fields: (url: string, requireUnique?: boolean) => Promise<SiteField[]>;
    ensure: (url: string) => Promise<void>;
};
export {};
//# sourceMappingURL=spfx-site-key-value-store.internal.d.ts.map