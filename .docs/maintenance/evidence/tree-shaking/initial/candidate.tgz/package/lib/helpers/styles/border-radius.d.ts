import { SxBaseDescriptor } from './types';
/** Applies var(--borderRadiusNone) to all four border corners. It does not change dimensions.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderRadius.none)
 */
export declare const none: SxBaseDescriptor;
/** Applies var(--borderRadiusSmall) to all four border corners. It does not change dimensions.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderRadius.small)
 */
export declare const small: SxBaseDescriptor;
/** Applies var(--borderRadiusMedium) to all four border corners. It does not change dimensions.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderRadius.medium)
 */
export declare const medium: SxBaseDescriptor;
/** Applies var(--borderRadiusLarge) to all four border corners. It does not change dimensions.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderRadius.large)
 */
export declare const large: SxBaseDescriptor;
/** Applies var(--borderRadiusXLarge) to all four border corners. It does not change dimensions.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderRadius.extraLarge)
 */
export declare const extraLarge: SxBaseDescriptor;
/** Applies var(--borderRadiusCircular) to all four border corners. It does not change dimensions.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderRadius.circular)
 */
export declare const circular: SxBaseDescriptor;
//# sourceMappingURL=border-radius.d.ts.map