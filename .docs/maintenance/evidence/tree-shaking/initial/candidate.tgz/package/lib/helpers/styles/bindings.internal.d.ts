import type { GriffelStyle } from '@griffel/core';
import type { SxBinding, SxState } from './descriptor.internal';
import { SxNormalizedDeclaration, SxQuery } from './normalize.internal';
/** Native property/scope identity merges with foreign Griffel classes; every scope reads the same priority chain. */
export declare function createBindingStyle(binding: SxBinding, query: SxQuery, state?: SxState): GriffelStyle;
/** Scoped assignments are ordinary Griffel declarations, never inline style. */
export declare function createAssignmentStyle(declaration: SxNormalizedDeclaration): GriffelStyle;
//# sourceMappingURL=bindings.internal.d.ts.map