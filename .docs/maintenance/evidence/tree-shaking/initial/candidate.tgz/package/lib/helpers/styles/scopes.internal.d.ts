import { SxBaseDescriptor, SxStateDescriptor, SxResponsiveDescriptor } from './types';
import { SxBreakpoint, SxQueryTarget, SxState } from './descriptor.internal';
export declare function createState(state: SxState, inputs: readonly SxBaseDescriptor[]): SxStateDescriptor;
export declare function createResponsive(target: SxQueryTarget, breakpoint: SxBreakpoint, inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[]): SxResponsiveDescriptor;
//# sourceMappingURL=scopes.internal.d.ts.map