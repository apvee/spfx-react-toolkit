import { SxBaseDescriptor } from './types';
/** Sets maxHeight to none.
 * @example sx(maxHeight.none)
 */
export declare const none: SxBaseDescriptor;
/** Creates an explicit pixel maxHeight.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable maxHeight descriptor.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(maxHeight.px(240))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=max-height.d.ts.map