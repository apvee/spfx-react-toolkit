import { SxBaseDescriptor } from './types';
/** Row gap uses vertical and column gap uses horizontal Fluent None spacing tokens.
 * @example sx(gap.none)
 */
export declare const none: SxBaseDescriptor;
/** Row gap uses vertical and column gap uses horizontal Fluent XS spacing tokens.
 * @example sx(gap.extraSmall)
 */
export declare const extraSmall: SxBaseDescriptor;
/** Row gap uses vertical and column gap uses horizontal Fluent S spacing tokens.
 * @example sx(gap.small)
 */
export declare const small: SxBaseDescriptor;
/** Row gap uses vertical and column gap uses horizontal Fluent M spacing tokens.
 * @example sx(gap.medium)
 */
export declare const medium: SxBaseDescriptor;
/** Row gap uses vertical and column gap uses horizontal Fluent L spacing tokens.
 * @example sx(gap.large)
 */
export declare const large: SxBaseDescriptor;
/** Row gap uses vertical and column gap uses horizontal Fluent XL spacing tokens.
 * @example sx(gap.extraLarge)
 */
export declare const extraLarge: SxBaseDescriptor;
/** Creates explicit pixel spacing on the row and column gaps.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable canonical longhand recipe; does not change display.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(gap.px(12))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=gap.d.ts.map