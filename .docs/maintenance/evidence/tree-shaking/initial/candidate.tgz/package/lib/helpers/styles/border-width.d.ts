import { SxBaseDescriptor } from './types';
/** Applies 0px to all four border sides. Compose border width, style, and color explicitly.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderWidth.none)
 */
export declare const none: SxBaseDescriptor;
/** Applies var(--strokeWidthThin) to all four border sides. Compose border width, style, and color explicitly.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderWidth.thin)
 */
export declare const thin: SxBaseDescriptor;
/** Applies var(--strokeWidthThick) to all four border sides. Compose border width, style, and color explicitly.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderWidth.thick)
 */
export declare const thick: SxBaseDescriptor;
//# sourceMappingURL=border-width.d.ts.map