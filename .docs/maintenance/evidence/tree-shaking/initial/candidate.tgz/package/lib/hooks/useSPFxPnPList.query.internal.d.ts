import type { IItems } from '@pnp/sp/items';
export interface QueryTopTracker {
    top?: number;
}
export interface EffectiveListQuery {
    readonly query: IItems;
    readonly pageSize: number | undefined;
}
export declare function createMonitoredListQuery(target: IItems, tracker: QueryTopTracker): IItems;
export declare function resolveEffectiveListQuery(userQuery: IItems, tracker: QueryTopTracker, pageSize: number | undefined): EffectiveListQuery;
export declare function hasMoreListItems(resultLength: number, pageSize: number | undefined): boolean;
//# sourceMappingURL=useSPFxPnPList.query.internal.d.ts.map