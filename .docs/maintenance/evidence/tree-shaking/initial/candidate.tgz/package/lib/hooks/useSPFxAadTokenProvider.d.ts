import type { AadTokenProvider } from '@microsoft/sp-http';
/**
 * Return type for useSPFxAadTokenProvider hook
 */
export interface SPFxAadTokenProviderInfo {
    /**
     * Native AadTokenProvider from SPFx.
     * Provides access tokens for Azure AD-secured resources.
     * Will be undefined until initialization completes.
     */
    readonly tokenProvider: AadTokenProvider | undefined;
    /**
     * True while the AAD token provider is being initialized.
     * Use this to show a loading indicator during startup.
     */
    readonly isInitializing: boolean;
    /**
     * Error that occurred during token provider initialization.
     * If set, the token provider will remain undefined.
     */
    readonly initError: Error | undefined;
    /**
     * Computed state: true when token provider is ready for use.
     * Equivalent to: tokenProvider !== undefined && !isInitializing && !initError
     */
    readonly isReady: boolean;
}
/**
 * Hook to access SPFx AadTokenProvider with built-in state management.
 *
 * @remarks
 * This hook consumes AadTokenProviderFactory from SPFx ServiceScope using
 * dependency injection. The factory is consumed lazily and cached. The
 * factory.getTokenProvider() method is then called asynchronously to obtain
 * the AadTokenProvider instance.
 */
export declare function useSPFxAadTokenProvider(): SPFxAadTokenProviderInfo;
//# sourceMappingURL=useSPFxAadTokenProvider.d.ts.map