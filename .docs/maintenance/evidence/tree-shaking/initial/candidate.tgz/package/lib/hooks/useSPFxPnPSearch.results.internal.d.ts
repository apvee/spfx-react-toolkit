import type { IRefiner, ISearchResult } from '@pnp/sp/search';
import type { SearchRefiner, SearchResult } from './useSPFxPnPSearch';
export declare function parseSearchResults<T>(rawResults: ISearchResult[]): SearchResult<T>[];
export declare function parseSearchRefiners(refinerResults: IRefiner[]): SearchRefiner[];
export declare function buildRefinementFilters(refinersToApply: Map<string, string[]>): string[];
//# sourceMappingURL=useSPFxPnPSearch.results.internal.d.ts.map