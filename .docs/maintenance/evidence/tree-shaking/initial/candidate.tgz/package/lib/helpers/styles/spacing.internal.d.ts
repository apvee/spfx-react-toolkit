import { SxBaseDescriptor } from './types';
import { SxProperty } from './descriptor.internal';
/** Exact Fluent spacing suffixes supported by the public catalog. */
export type SpacingSuffix = 'None' | 'XS' | 'S' | 'M' | 'L' | 'XL';
/** Creates canonical longhands using the separate Fluent block and inline token scales. */
export declare function createSpacing(name: string, blockProperties: readonly SxProperty[], inlineProperties: readonly SxProperty[], suffix: SpacingSuffix): SxBaseDescriptor;
/** Creates explicit canonical pixel longhands with the shared finite nonnegative validation. */
export declare function createSpacingPixels(name: string, properties: readonly SxProperty[], value: number): SxBaseDescriptor;
//# sourceMappingURL=spacing.internal.d.ts.map