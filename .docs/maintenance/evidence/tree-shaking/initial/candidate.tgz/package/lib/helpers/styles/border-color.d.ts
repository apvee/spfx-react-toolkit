import { SxBaseDescriptor } from './types';
/** Applies var(--colorNeutralStroke1) to all four border sides. It does not add border width or style.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderColor.primary)
 */
export declare const primary: SxBaseDescriptor;
/** Applies var(--colorNeutralStroke2) to all four border sides. It does not add border width or style.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderColor.subtle)
 */
export declare const subtle: SxBaseDescriptor;
/** Applies var(--colorBrandStroke1) to all four border sides. It does not add border width or style.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderColor.brand)
 */
export declare const brand: SxBaseDescriptor;
/** Applies var(--colorNeutralStrokeDisabled) to all four border sides. It does not add border width or style.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderColor.disabled)
 */
export declare const disabled: SxBaseDescriptor;
//# sourceMappingURL=border-color.d.ts.map