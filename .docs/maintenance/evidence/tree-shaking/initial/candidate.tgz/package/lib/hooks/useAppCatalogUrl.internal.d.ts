/// <reference types="react" />
import type { SPHttpClient } from '@microsoft/sp-http';
/**
 * Return type for useAppCatalogUrl internal hook
 */
export interface AppCatalogUrlInfo {
    /** Resolved tenant app catalog URL, or undefined if not yet discovered */
    readonly appCatalogUrl: string | undefined;
    /** SPHttpClient instance from context */
    readonly spHttpClient: SPHttpClient | undefined;
    /** Discover and return the tenant app catalog URL (cached after first call) */
    readonly discoverAppCatalogUrl: () => Promise<string>;
    /** Check if current user is Site Collection Admin on the app catalog */
    readonly checkWritePermission: (catalogUrl: string) => Promise<boolean>;
    /** Ref tracking component mounted state */
    readonly isMountedRef: React.MutableRefObject<boolean>;
}
/**
 * Internal hook to discover and cache the tenant app catalog URL.
 * Shared by useSPFxTenantProperty and useSPFxTenantKeyValueStore.
 *
 * @returns Object with app catalog URL, discovery function, and permission check
 * @internal
 */
export declare function useAppCatalogUrl(): AppCatalogUrlInfo;
//# sourceMappingURL=useAppCatalogUrl.internal.d.ts.map