import { SxBaseDescriptor, SxDescriptor, SxStateDescriptor, SxResponsiveDescriptor } from './types';
/** Finite normalized longhand properties owned by the v1 catalog. */
export type SxProperty = 'display' | 'flexDirection' | 'flexWrap' | 'flexGrow' | 'flexShrink' | 'gridTemplateColumns' | 'alignItems' | 'justifyContent' | 'alignSelf' | 'rowGap' | 'columnGap' | 'paddingTop' | 'paddingRight' | 'paddingBottom' | 'paddingLeft' | 'paddingInlineStart' | 'paddingInlineEnd' | 'paddingBlockStart' | 'paddingBlockEnd' | 'marginTop' | 'marginRight' | 'marginBottom' | 'marginLeft' | 'marginInlineStart' | 'marginInlineEnd' | 'marginBlockStart' | 'marginBlockEnd' | 'width' | 'height' | 'minWidth' | 'minHeight' | 'maxWidth' | 'maxHeight' | 'color' | 'backgroundColor' | 'fontFamily' | 'fontSize' | 'fontWeight' | 'lineHeight' | 'textAlign' | 'whiteSpace' | 'textOverflow' | 'borderTopWidth' | 'borderRightWidth' | 'borderBottomWidth' | 'borderLeftWidth' | 'borderTopStyle' | 'borderRightStyle' | 'borderBottomStyle' | 'borderLeftStyle' | 'borderTopColor' | 'borderRightColor' | 'borderBottomColor' | 'borderLeftColor' | 'borderTopLeftRadius' | 'borderTopRightRadius' | 'borderBottomLeftRadius' | 'borderBottomRightRadius' | 'boxShadow' | 'overflowX' | 'overflowY' | 'scrollbarWidth' | 'scrollbarColor' | 'containerType' | 'containerName';
/** Property binding's native/base fallback before any scoped value is active. */
export interface SxBinding {
    readonly property: SxProperty;
    readonly fallback: string;
    /** Optional native value used when the forced-colors media feature is active. */
    readonly forcedColors?: string;
}
export interface SxDeclarationData extends SxBaseDescriptor {
    readonly kind: 'declaration';
    readonly property: SxProperty;
    readonly value: string;
    readonly binding: SxBinding;
}
export interface SxRecipeData extends SxBaseDescriptor {
    readonly kind: 'recipe';
    readonly name: string;
    readonly declarations: readonly SxBaseDescriptor[];
}
export type SxBaseData = SxDeclarationData | SxRecipeData;
export type SxState = 'hover' | 'active' | 'focus-visible';
export type SxBreakpoint = 480 | 640 | 1024;
export type SxQueryTarget = 'container' | 'viewport';
export interface SxStateData extends SxStateDescriptor {
    readonly kind: 'state';
    readonly state: SxState;
    readonly inputs: readonly SxBaseDescriptor[];
}
export interface SxResponsiveData extends SxResponsiveDescriptor {
    readonly kind: 'responsive';
    readonly target: SxQueryTarget;
    readonly breakpoint: SxBreakpoint;
    readonly inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[];
}
export type SxDescriptorData = SxBaseData | SxStateData | SxResponsiveData;
/** Creates data only: no renderer, CSS insertion, or DOM access. */
export declare function createDeclaration(property: SxProperty, value: string, binding: SxBinding): SxBaseDescriptor;
/** Copies and freezes recipe inputs, preserving declaration order. */
export declare function createRecipe(name: string, declarations: readonly SxBaseDescriptor[]): SxBaseDescriptor;
/** Reads factory-owned data behind the opaque public contract. */
export declare function getDescriptorData(descriptor: SxDescriptor): SxDescriptorData;
/** Serializes finite, nonnegative CSS pixel lengths, including explicit zero. */
export declare function toPixels(value: number): string;
//# sourceMappingURL=descriptor.internal.d.ts.map