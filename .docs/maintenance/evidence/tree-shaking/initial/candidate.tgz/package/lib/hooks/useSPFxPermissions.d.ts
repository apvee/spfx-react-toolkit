import type { SPPermission } from '@microsoft/sp-page-context';
/**
 * Return type for useSPFxPermissions hook
 */
export interface SPFxPermissionsInfo {
    /** Site collection permissions */
    readonly sitePermissions: SPPermission | undefined;
    /** Web permissions */
    readonly webPermissions: SPPermission | undefined;
    /** List permissions (if in list context) */
    readonly listPermissions: SPPermission | undefined;
    /**
     * Check if user has specific web permission
     * @param permission - SPPermission to check (e.g., SPPermission.manageWeb, SPPermission.editListItems)
     * @returns True if user has the permission at web level
     */
    readonly hasWebPermission: (permission: SPPermission) => boolean;
    /**
     * Check if user has specific site collection permission
     * @param permission - SPPermission to check (e.g., SPPermission.manageWeb, SPPermission.createGroups)
     * @returns True if user has the permission at site collection level
     */
    readonly hasSitePermission: (permission: SPPermission) => boolean;
    /**
     * Check if user has specific list permission
     * @param permission - SPPermission to check (e.g., SPPermission.addListItems, SPPermission.deleteListItems)
     * @returns True if user has the permission at list level, false if no list context
     */
    readonly hasListPermission: (permission: SPPermission) => boolean;
}
/**
 * Hook for SharePoint permissions checking
 *
 * Provides access to current user's permissions at different scopes:
 * - Site collection level
 * - Web (subsite) level
 * - List level (if applicable)
 *
 * Includes helper methods for permission checks using SPPermission enum.
 *
 * Common permissions to check:
 * - SPPermission.manageWeb
 * - SPPermission.addListItems
 * - SPPermission.editListItems
 * - SPPermission.deleteListItems
 * - SPPermission.viewListItems
 * - SPPermission.managePermissions
 *
 * Useful for:
 * - Conditional UI rendering
 * - Feature availability
 * - Security trimming
 * - Authorization checks
 *
 * @returns Permissions and helper methods
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { web, hasWebPermission } = useSPFxPermissions();
 *   const canManage = hasWebPermission(SPPermission.manageWeb);
 *
 *   return (
 *     <div>
 *       {canManage && <button>Manage Settings</button>}
 *       <p>Can manage: {canManage ? 'Yes' : 'No'}</p>
 *     </div>
 *   );
 * }
 * ```
 */
export declare function useSPFxPermissions(): SPFxPermissionsInfo;
//# sourceMappingURL=useSPFxPermissions.d.ts.map