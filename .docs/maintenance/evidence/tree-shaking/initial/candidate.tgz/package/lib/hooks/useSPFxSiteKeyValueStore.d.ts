/** A key and its deserialized value from the collection's root-web store. */
export interface SPFxSiteKeyValueStoreItem<T = unknown> {
    /** Property key, stored in the Title column. */
    readonly key: string;
    /** Deserialized value; the generic does not perform runtime validation. */
    readonly value: T;
    /** Optional description metadata. */
    readonly description: string | undefined;
    /** SharePoint list item ID. */
    readonly id: number;
}
/** State and operations for a site collection key-value store. */
export interface SPFxSiteKeyValueStoreResult {
    /** True while any read operation is pending. */
    readonly isLoading: boolean;
    /** Error from the latest-started read; cleared when another read starts. */
    readonly error: Error | undefined;
    /** True while any write operation is pending. */
    readonly isWriting: boolean;
    /** Error from the latest-started write; cleared when another write starts. */
    readonly writeError: Error | undefined;
    /** Effective write permission indicator, refreshed after successful writes. */
    readonly canWrite: boolean;
    /** True when the client and a nonempty collection root URL are available. */
    readonly isReady: boolean;
    /** Reads a key without provisioning; failures set error and return undefined. */
    readonly get: <T = unknown>(key: string) => Promise<SPFxSiteKeyValueStoreItem<T> | undefined>;
    /** Reads all keys without provisioning; failures set error and return an empty array. */
    readonly list: () => Promise<SPFxSiteKeyValueStoreItem<unknown>[]>;
    /** Creates or updates a key, provisioning if needed; failures reject. */
    readonly save: <T = unknown>(key: string, value: T, description?: string) => Promise<void>;
    /** Removes a key without creating a missing store; failures reject. */
    readonly remove: (key: string) => Promise<void>;
}
/**
 * Manages SiteKeyValueStore in pageContext.site.absoluteUrl, shared by all subsites.
 * Mount checks permissions without provisioning. SharePoint enforces actual grants;
 * canWrite is an indicator, not authorization. Not-ready operations reject.
 * Reads and writes retain their original collection/client across context changes.
 */
export declare function useSPFxSiteKeyValueStore(): SPFxSiteKeyValueStoreResult;
//# sourceMappingURL=useSPFxSiteKeyValueStore.d.ts.map