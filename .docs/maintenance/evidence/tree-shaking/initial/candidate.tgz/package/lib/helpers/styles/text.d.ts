import { SxBaseDescriptor } from './types';
/** Allows normal line wrapping without changing overflow or dimensions.
 * @example sx(text.wrap)
 */
export declare const wrap: SxBaseDescriptor;
/** Prevents line wrapping without changing overflow or dimensions.
 * @example sx(text.noWrap)
 */
export declare const noWrap: SxBaseDescriptor;
/** Requests one-line ellipsis with hidden overflow on both axes.
 * Requires a constrained available width; adds no display or minWidth.
 * @example sx(text.truncate, width.px(240))
 */
export declare const truncate: SxBaseDescriptor;
//# sourceMappingURL=text.d.ts.map