import { SxBaseDescriptor } from './types';
/** Sets height to auto.
 * @example sx(height.auto)
 */
export declare const auto: SxBaseDescriptor;
/** Full height of the containing block; percentage sizing requires a definite containing height.
 * @example sx(height.full)
 */
export declare const full: SxBaseDescriptor;
/** Creates an explicit pixel height.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable height descriptor.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(height.px(240))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=height.d.ts.map