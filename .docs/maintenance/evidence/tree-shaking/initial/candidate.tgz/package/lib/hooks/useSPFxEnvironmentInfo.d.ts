/**
 * SPFx environment types
 */
export type SPFxEnvironmentType = 'Local' | 'SharePoint' | 'SharePointOnPrem' | 'Teams' | 'Office' | 'Outlook';
/**
 * Return type for useSPFxEnvironmentInfo hook
 */
export interface SPFxEnvironmentInfo {
    /** Current environment type */
    readonly type: SPFxEnvironmentType;
    /** Whether running in local workbench */
    readonly isLocal: boolean;
    /** Whether running in SharePoint workbench (hosted or local) */
    readonly isWorkbench: boolean;
    /** Whether running in SharePoint Online */
    readonly isSharePoint: boolean;
    /** Whether running in SharePoint On-Premises */
    readonly isSharePointOnPrem: boolean;
    /** Whether running in Microsoft Teams */
    readonly isTeams: boolean;
    /** Whether running in Office application */
    readonly isOffice: boolean;
    /** Whether running in Outlook */
    readonly isOutlook: boolean;
}
/**
 * Hook to access SPFx environment type information
 *
 * Detects the current host environment:
 * - Local: Local workbench (localhost)
 * - SharePoint: SharePoint Online
 * - SharePointOnPrem: SharePoint On-Premises
 * - Teams: Microsoft Teams
 * - Office: Office applications
 * - Outlook: Outlook
 *
 * Useful for:
 * - Environment-specific rendering
 * - Feature availability checks
 * - API endpoint selection
 * - Debugging information
 *
 * @returns Environment information
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { type, isTeams, isLocal } = useSPFxEnvironmentInfo();
 *
 *   if (isLocal) {
 *     return <div>Development Mode</div>;
 *   }
 *
 *   if (isTeams) {
 *     return <TeamsSpecificUI />;
 *   }
 *
 *   return <SharePointUI />;
 * }
 * ```
 */
export declare function useSPFxEnvironmentInfo(): SPFxEnvironmentInfo;
//# sourceMappingURL=useSPFxEnvironmentInfo.d.ts.map