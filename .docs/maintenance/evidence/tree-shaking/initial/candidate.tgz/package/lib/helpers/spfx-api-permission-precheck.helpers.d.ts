export type SPFxApiPermissionPrecheckMode = 'passive' | 'interactiveAllowed';
export type SPFxApiPermissionConfigurationState = 'idle' | 'checking' | 'ready' | 'actionRequired' | 'cannotDetermine';
export type SPFxApiPermissionCheckStatus = 'available' | 'missingScope' | 'consentRequired' | 'interactionRequired' | 'claimsChallenge' | 'conditionalAccessBlocked' | 'accessRestricted' | 'resourceMisconfigured' | 'tokenProviderUnavailable' | 'audienceMismatch' | 'unsupportedToken' | 'unsupportedPermissionKind' | 'tokenExpired' | 'transientFailure' | 'timeout' | 'invalidRequirement' | 'unknown';
export type SPFxApiPermissionSeverity = 'ok' | 'warning' | 'error' | 'unknown';
export interface SPFxPermissionScopeOptions {
    readonly scope: string;
    readonly required?: boolean;
    readonly satisfies?: readonly string[];
    readonly label?: string;
}
export type SPFxPermissionScopeInput = string | SPFxPermissionScopeOptions;
export interface SPFxCustomApiPermissionInput {
    readonly id?: string;
    readonly name: string;
    readonly resource: string;
    readonly packageResource?: string;
    readonly scopes: readonly SPFxPermissionScopeInput[];
    readonly expectedAudiences?: readonly string[];
}
export interface SPFxApiPermissionPrecheckConfig {
    readonly graph?: readonly SPFxPermissionScopeInput[];
    readonly customApis?: readonly SPFxCustomApiPermissionInput[];
    readonly requirements?: readonly SPFxApiPermissionRequirement[];
}
export interface SPFxApiPermissionRequirement {
    readonly id: string;
    readonly resourceName: string;
    readonly resourceEndpoint: string;
    readonly packageResource: string;
    readonly scope: string;
    readonly kind: 'delegatedScope';
    readonly required: boolean;
    readonly satisfies?: readonly string[];
    readonly expectedAudiences?: readonly string[];
    readonly adminMessage: string;
    readonly label?: string;
}
export interface SPFxApiPermissionPackageSolutionEntry {
    readonly resource: string;
    readonly scope: string;
}
export interface SPFxApiPermissionSummary {
    readonly id: string;
    readonly resourceName: string;
    readonly resourceEndpoint: string;
    readonly scope: string;
    readonly required: boolean;
    readonly status: SPFxApiPermissionCheckStatus;
    readonly severity: SPFxApiPermissionSeverity;
    readonly message: string;
    readonly adminMessage: string;
    readonly packageSolutionEntry: SPFxApiPermissionPackageSolutionEntry;
    readonly matchedScope?: string;
    readonly errorCode?: string;
}
export interface SPFxApiPermissionCheckResult extends SPFxApiPermissionSummary {
    readonly detectedScopes: readonly string[];
    readonly audience?: string;
    readonly tenantId?: string;
    readonly caseMismatchScope?: string;
}
export interface SPFxJwtPayload {
    readonly aud?: string | readonly string[];
    readonly scp?: string;
    readonly roles?: readonly string[] | string;
    readonly tid?: string;
    readonly exp?: number;
    readonly nbf?: number;
    readonly [key: string]: unknown;
}
export declare const SPFX_GRAPH_RESOURCE_NAME = "Microsoft Graph";
export declare const SPFX_GRAPH_RESOURCE_ENDPOINT = "https://graph.microsoft.com";
export declare const SPFX_GRAPH_APP_ID = "00000003-0000-0000-c000-000000000000";
export declare function normalizeSPFxApiPermissionRequirements(config: SPFxApiPermissionPrecheckConfig): readonly SPFxApiPermissionRequirement[];
export declare function buildSPFxApiPermissionAdminMessage(packageResource: string, scope: string): string;
export declare function createSPFxApiPermissionRequirementId(resourceEndpoint: string, scope: string, prefix?: string): string;
export declare function validateSPFxApiPermissionRequirement(requirement: SPFxApiPermissionRequirement): SPFxApiPermissionCheckResult | undefined;
export declare function decodeSPFxJwtPayload(token: string): SPFxJwtPayload | undefined;
export declare function extractSPFxDelegatedScopes(payload: SPFxJwtPayload): readonly string[];
export declare function evaluateSPFxApiPermissionRequirement(requirement: SPFxApiPermissionRequirement, payload: SPFxJwtPayload | undefined, options?: {
    readonly validateAudience?: boolean;
}): SPFxApiPermissionCheckResult;
export declare function classifySPFxApiPermissionError(requirement: SPFxApiPermissionRequirement, error: unknown): SPFxApiPermissionCheckResult;
export declare function summarizeSPFxApiPermissionResults(results: readonly SPFxApiPermissionCheckResult[], isChecking?: boolean): {
    readonly configurationState: SPFxApiPermissionConfigurationState;
    readonly isConfigured: boolean;
    readonly available: readonly SPFxApiPermissionSummary[];
    readonly missing: readonly SPFxApiPermissionSummary[];
    readonly warnings: readonly SPFxApiPermissionSummary[];
    readonly unknown: readonly SPFxApiPermissionSummary[];
};
//# sourceMappingURL=spfx-api-permission-precheck.helpers.d.ts.map