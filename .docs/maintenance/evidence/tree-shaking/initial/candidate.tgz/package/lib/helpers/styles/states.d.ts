import { SxBaseDescriptor, SxStateDescriptor } from './types';
/** Applies base descriptors during CSS :hover; does not infer interaction tokens.
 * @param inputs Base descriptors; nested states and class strings are unsupported.
 * @returns Immutable state descriptor.
 * @example responsive.medium(hover(foreground.subtle))
 */
export declare function hover(...inputs: readonly SxBaseDescriptor[]): SxStateDescriptor;
/** Applies base descriptors during CSS :active; does not infer interaction tokens.
 * @param inputs Base descriptors; nested states and class strings are unsupported.
 * @returns Immutable state descriptor.
 * @example responsive.medium(active(foreground.subtle))
 */
export declare function active(...inputs: readonly SxBaseDescriptor[]): SxStateDescriptor;
/** Applies base descriptors during CSS :focus-visible; does not infer interaction tokens.
 * @param inputs Base descriptors; nested states and class strings are unsupported.
 * @returns Immutable state descriptor.
 * @example responsive.medium(focusVisible(foreground.subtle))
 */
export declare function focusVisible(...inputs: readonly SxBaseDescriptor[]): SxStateDescriptor;
//# sourceMappingURL=states.d.ts.map