import { SxBaseDescriptor } from './types';
/** Sets vertical overflow to visible; the other axis retains native CSS behavior.
 * CSS can compute visible to auto when the other axis is hidden or auto.
 * @example sx(overflow.vertical.visible)
 */
export declare const visible: SxBaseDescriptor;
/** Sets vertical overflow to hidden; the other axis retains native CSS behavior.
 * CSS can compute visible to auto when the other axis is hidden or auto.
 * @example sx(overflow.vertical.hidden)
 */
export declare const hidden: SxBaseDescriptor;
/** Sets vertical overflow to auto; the other axis retains native CSS behavior.
 * CSS can compute visible to auto when the other axis is hidden or auto.
 * @example sx(overflow.vertical.auto)
 */
export declare const auto: SxBaseDescriptor;
//# sourceMappingURL=overflow-vertical.d.ts.map