import type { SPPermission } from '@microsoft/sp-page-context';
/**
 * Checks whether an SPFx permission set contains a specific permission.
 *
 * @param permissionSet - Permission set to check
 * @param permission - Required permission
 * @returns True when the permission is present
 */
export declare function hasSPFxPermission(permissionSet: SPPermission | undefined, permission: SPPermission): boolean;
//# sourceMappingURL=spfx-permissions.helpers.d.ts.map