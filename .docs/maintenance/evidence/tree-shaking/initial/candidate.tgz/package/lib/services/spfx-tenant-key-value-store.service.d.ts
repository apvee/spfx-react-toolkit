import { SPHttpClient } from '@microsoft/sp-http';
export interface SPFxTenantKeyValueStoreServiceItem<T = unknown> {
    readonly key: string;
    readonly value: T;
    readonly description: string | undefined;
    readonly id: number;
}
export interface SPFxTenantKeyValueStoreService {
    ensureListReady: (catalogUrl: string) => Promise<void>;
    get: <T = unknown>(key: string, catalogUrl: string) => Promise<SPFxTenantKeyValueStoreServiceItem<T> | undefined>;
    list: (catalogUrl: string) => Promise<SPFxTenantKeyValueStoreServiceItem<unknown>[]>;
    save: <T = unknown>(key: string, value: T, catalogUrl: string, description?: string) => Promise<void>;
    remove: (key: string, catalogUrl: string) => Promise<void>;
}
export declare function createSPFxTenantKeyValueStoreService(spHttpClient: SPHttpClient): SPFxTenantKeyValueStoreService;
//# sourceMappingURL=spfx-tenant-key-value-store.service.d.ts.map