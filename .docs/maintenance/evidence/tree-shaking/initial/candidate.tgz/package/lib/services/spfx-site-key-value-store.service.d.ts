import { SPHttpClient } from '@microsoft/sp-http';
/** A stored site collection key and its deserialized value. */
export interface SPFxSiteKeyValueStoreServiceItem<T = unknown> {
    readonly key: string;
    readonly value: T;
    readonly description: string | undefined;
    readonly id: number;
}
/** Non-React CRUD and permission checks for a collection's root-web store. */
export interface SPFxSiteKeyValueStoreService {
    ensureListReady: (siteCollectionUrl: string) => Promise<void>;
    get: <T = unknown>(key: string, siteCollectionUrl: string) => Promise<SPFxSiteKeyValueStoreServiceItem<T> | undefined>;
    list: (siteCollectionUrl: string) => Promise<SPFxSiteKeyValueStoreServiceItem<unknown>[]>;
    save: <T = unknown>(key: string, value: T, siteCollectionUrl: string, description?: string) => Promise<void>;
    remove: (key: string, siteCollectionUrl: string) => Promise<void>;
    canCurrentUserWrite: (siteCollectionUrl: string) => Promise<boolean>;
}
/** Creates an isolated service; pass pageContext.site.absoluteUrl as the collection URL. */
export declare function createSPFxSiteKeyValueStoreService(spHttpClient: SPHttpClient): SPFxSiteKeyValueStoreService;
//# sourceMappingURL=spfx-site-key-value-store.service.d.ts.map