import { SxBaseDescriptor } from './types';
/** Sets minHeight to 0px.
 * @example sx(minHeight.zero)
 */
export declare const zero: SxBaseDescriptor;
/** Creates an explicit pixel minHeight.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable minHeight descriptor.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(minHeight.px(240))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=min-height.d.ts.map