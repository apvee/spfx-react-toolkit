import { SxBaseDescriptor } from './types';
/** Applies solid to all four border sides. Compose border width, style, and color explicitly.
 * Token values require scoped Fluent theme variables.
 * @example sx(borderStyle.solid)
 */
export declare const solid: SxBaseDescriptor;
//# sourceMappingURL=border-style.d.ts.map