import * as React from 'react';
import type { SPFxContextValue } from './types';
/**
 * React Context for SPFx metadata
 * Contains only static reference data:
 * - instanceId: Unique identifier for this SPFx instance
 * - spfxContext: The SPFx context object (WebPartContext, etc.)
 * - kind: Type of host component
 *
 * This context does NOT contain reactive state.
 * State is managed via isolated runtime stores per Provider instance.
 *
 * @internal
 */
export declare const SPFxContext: React.Context<SPFxContextValue | null>;
/**
 * Internal hook to access SPFx context
 *
 * Provides access to the SPFx context value containing instanceId, spfxContext, and kind.
 * Must be used within an SPFx provider component tree.
 *
 * @returns SPFxContextValue containing instanceId, spfxContext, and kind
 * @throws Error if used outside an SPFx provider - component must be wrapped with a host-specific provider.
 *
 * @internal
 */
export declare function useSPFxContext(): SPFxContextValue;
//# sourceMappingURL=context.internal.d.ts.map