import { SxBaseDescriptor } from './types';
/** Sets justifyContent to start without changing display. Uses logical CSS alignment, respecting writing mode and direction.
 * @example sx(justifyContent.start)
 */
export declare const start: SxBaseDescriptor;
/** Sets justifyContent to center without changing display.
 * @example sx(justifyContent.center)
 */
export declare const center: SxBaseDescriptor;
/** Sets justifyContent to end without changing display. Uses logical CSS alignment, respecting writing mode and direction.
 * @example sx(justifyContent.end)
 */
export declare const end: SxBaseDescriptor;
/** Sets justifyContent to space-between without changing display.
 * @example sx(justifyContent.spaceBetween)
 */
export declare const spaceBetween: SxBaseDescriptor;
//# sourceMappingURL=justify-content.d.ts.map