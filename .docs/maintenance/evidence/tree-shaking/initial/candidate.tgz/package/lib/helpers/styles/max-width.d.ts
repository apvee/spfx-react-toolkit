import { SxBaseDescriptor } from './types';
/** Sets maxWidth to none.
 * @example sx(maxWidth.none)
 */
export declare const none: SxBaseDescriptor;
/** Creates an explicit pixel maxWidth.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable maxWidth descriptor.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(maxWidth.px(240))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=max-width.d.ts.map