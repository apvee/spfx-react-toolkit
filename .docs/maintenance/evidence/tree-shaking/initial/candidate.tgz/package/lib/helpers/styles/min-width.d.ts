import { SxBaseDescriptor } from './types';
/** Explicit zero minimum width.
 * @example sx(minWidth.zero)
 */
export declare const zero: SxBaseDescriptor;
/** Creates an explicit pixel width.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable minWidth descriptor.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(minWidth.px(240))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=min-width.d.ts.map