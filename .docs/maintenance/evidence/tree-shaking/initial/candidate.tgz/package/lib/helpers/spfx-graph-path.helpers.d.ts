type SPFxUserPhotoOptionsResult = {
    readonly userId?: string;
    readonly email?: string;
    readonly size?: '48x48' | '64x64' | '96x96' | '120x120' | '240x240' | '360x360' | '432x432' | '504x504' | '648x648';
};
/**
 * Builds a Microsoft Graph path for a file in the user's OneDrive app root.
 *
 * @param fileName - Name of the file
 * @param folder - Optional folder namespace
 * @returns Full Graph API path for file content
 */
export declare function buildOneDriveAppDataPath(fileName: string, folder?: string): string;
/**
 * Builds the Microsoft Graph profile photo endpoint.
 *
 * @param options - Optional user identifier and photo size
 * @returns Graph endpoint for the requested user photo
 */
export declare function buildUserPhotoEndpoint(options?: SPFxUserPhotoOptionsResult): string;
export {};
//# sourceMappingURL=spfx-graph-path.helpers.d.ts.map