import { SxBaseDescriptor, SxStateDescriptor, SxResponsiveDescriptor } from './types';
/** Applies descriptors at viewport width >= 480px.
 * @param inputs Base or state descriptors; nested queries and class strings are unsupported.
 * @returns Immutable viewport query descriptor.
 * @example viewport.small(hover(foreground.subtle))
 */
export declare function small(...inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[]): SxResponsiveDescriptor;
/** Applies descriptors at viewport width >= 640px.
 * @param inputs Base or state descriptors; nested queries and class strings are unsupported.
 * @returns Immutable viewport query descriptor.
 * @example viewport.medium(hover(foreground.subtle))
 */
export declare function medium(...inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[]): SxResponsiveDescriptor;
/** Applies descriptors at viewport width >= 1024px.
 * @param inputs Base or state descriptors; nested queries and class strings are unsupported.
 * @returns Immutable viewport query descriptor.
 * @example viewport.large(hover(foreground.subtle))
 */
export declare function large(...inputs: readonly (SxBaseDescriptor | SxStateDescriptor)[]): SxResponsiveDescriptor;
//# sourceMappingURL=viewport.d.ts.map