import { SxBaseDescriptor } from './types';
/** Creates a grid with equally sized columns that may shrink below content width.
 * @param count Positive integer column count.
 * @returns Immutable display and column-template recipe.
 * @throws {RangeError} When count is not a finite positive integer.
 * @example sx(grid.columns(3), gap.medium)
 */
export declare function columns(count: number): SxBaseDescriptor;
//# sourceMappingURL=grid.d.ts.map