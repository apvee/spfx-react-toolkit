import { SPHttpClient } from '@microsoft/sp-http';
import type { SPFxTenantKeyValueStoreItem } from './useSPFxTenantKeyValueStore';
export declare const TENANT_KEY_VALUE_STORE_LIST_TITLE = "TenantKeyValueStore";
export interface ListItemResponse {
    Id: number;
    Title: string;
    Value: string;
    Description?: string;
}
export interface ListItemsResponse {
    value: ListItemResponse[];
}
export interface FieldsCheckResponse {
    value: Array<{
        InternalName: string;
    }>;
}
export declare function getListApiUrl(catalogUrl: string): string;
export declare function createField(client: SPHttpClient, listApiUrl: string, fieldTitle: string): Promise<void>;
export declare function ensureTenantKeyValueStoreList(client: SPHttpClient, catalogUrl: string): Promise<void>;
export declare function findTenantKeyValueStoreItemByKey(client: SPHttpClient, catalogUrl: string, key: string): Promise<ListItemResponse | undefined>;
export declare function mapTenantKeyValueStoreItem<T>(raw: ListItemResponse): SPFxTenantKeyValueStoreItem<T>;
//# sourceMappingURL=useSPFxTenantKeyValueStore.sharepoint.internal.d.ts.map