import type { SPFI } from '@pnp/sp';
import '@pnp/sp/batching';
export interface SPFxPnPService {
    readonly sp: SPFI;
    invoke: <T>(fn: (sp: SPFI) => Promise<T>) => Promise<T>;
    batch: <T>(fn: (batchedSP: SPFI) => Promise<T>) => Promise<T>;
}
export declare function createSPFxPnPService(sp: SPFI): SPFxPnPService;
//# sourceMappingURL=spfx-pnp.service.d.ts.map