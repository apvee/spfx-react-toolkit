import type { MSGraphClientV3 } from '@microsoft/sp-http';
export interface SPFxOneDriveAppDataReadResult<T = unknown> {
    readonly data: T | undefined;
    readonly isNotFound: boolean;
}
export interface SPFxOneDriveAppDataService {
    read: <T = unknown>(fileName: string, folder?: string) => Promise<SPFxOneDriveAppDataReadResult<T>>;
    write: <T = unknown>(fileName: string, content: T, folder?: string) => Promise<void>;
}
export declare function createSPFxOneDriveAppDataService(graphClient: MSGraphClientV3): SPFxOneDriveAppDataService;
//# sourceMappingURL=spfx-onedrive-app-data.service.d.ts.map