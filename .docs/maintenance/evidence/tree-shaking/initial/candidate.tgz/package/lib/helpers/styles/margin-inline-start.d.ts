import { SxBaseDescriptor } from './types';
/** Logical block sides use vertical and inline sides use horizontal Fluent None spacing tokens.
 * @example sx(marginInlineStart.none)
 */
export declare const none: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent XS spacing tokens.
 * @example sx(marginInlineStart.extraSmall)
 */
export declare const extraSmall: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent S spacing tokens.
 * @example sx(marginInlineStart.small)
 */
export declare const small: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent M spacing tokens.
 * @example sx(marginInlineStart.medium)
 */
export declare const medium: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent L spacing tokens.
 * @example sx(marginInlineStart.large)
 */
export declare const large: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent XL spacing tokens.
 * @example sx(marginInlineStart.extraLarge)
 */
export declare const extraLarge: SxBaseDescriptor;
/** Creates explicit pixel spacing on the logical sides selected by marginInlineStart.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable canonical longhand recipe; does not change display.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(marginInlineStart.px(12))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=margin-inline-start.d.ts.map