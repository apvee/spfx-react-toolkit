import { SxBaseDescriptor } from './types';
/** Applies Fluent's colorNeutralForeground1 CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.primary)
 */
export declare const primary: SxBaseDescriptor;
/** Applies Fluent's colorNeutralForeground2 CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.subtle)
 */
export declare const subtle: SxBaseDescriptor;
/** Applies Fluent's colorNeutralForeground3 CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.muted)
 */
export declare const muted: SxBaseDescriptor;
/** Applies Fluent's colorNeutralForegroundDisabled CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.disabled)
 */
export declare const disabled: SxBaseDescriptor;
/** Applies Fluent's colorBrandForeground1 CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.brand)
 */
export declare const brand: SxBaseDescriptor;
/** Applies Fluent's colorNeutralForegroundOnBrand CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.onBrand)
 */
export declare const onBrand: SxBaseDescriptor;
/** Applies Fluent's colorNeutralForegroundInverted CSS variable.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.inverted)
 */
export declare const inverted: SxBaseDescriptor;
/** Applies Fluent's colorBrandForegroundLink CSS variable. Color only; adds no link semantics.
 * Requires theme variables in scope; adds no state or geometry.
 * @example sx(foreground.link)
 */
export declare const link: SxBaseDescriptor;
//# sourceMappingURL=foreground.d.ts.map