import { SxBaseDescriptor } from './types';
/** Logical block sides use vertical and inline sides use horizontal Fluent None spacing tokens.
 * @example sx(marginInlineEnd.none)
 */
export declare const none: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent XS spacing tokens.
 * @example sx(marginInlineEnd.extraSmall)
 */
export declare const extraSmall: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent S spacing tokens.
 * @example sx(marginInlineEnd.small)
 */
export declare const small: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent M spacing tokens.
 * @example sx(marginInlineEnd.medium)
 */
export declare const medium: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent L spacing tokens.
 * @example sx(marginInlineEnd.large)
 */
export declare const large: SxBaseDescriptor;
/** Logical block sides use vertical and inline sides use horizontal Fluent XL spacing tokens.
 * @example sx(marginInlineEnd.extraLarge)
 */
export declare const extraLarge: SxBaseDescriptor;
/** Creates explicit pixel spacing on the logical sides selected by marginInlineEnd.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable canonical longhand recipe; does not change display.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(marginInlineEnd.px(12))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=margin-inline-end.d.ts.map