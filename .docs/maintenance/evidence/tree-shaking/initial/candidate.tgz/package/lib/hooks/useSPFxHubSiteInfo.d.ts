/**
 * Return type for useSPFxHubSiteInfo hook
 */
export interface SPFxHubSiteInfo {
    /** Whether the current site is associated with a hub site */
    readonly isHubSite: boolean;
    /** Hub site ID (GUID) if associated, undefined otherwise */
    readonly hubSiteId: string | undefined;
    /** Hub site URL (fetched via REST API) */
    readonly hubSiteUrl: string | undefined;
    /** Whether hub site URL is being loaded */
    readonly isLoading: boolean;
    /** Error during hub site URL fetch */
    readonly error: Error | undefined;
}
/**
 * Hook for Hub Site information
 *
 * Provides information about SharePoint Hub Site association:
 * - isHubSite: Whether site is associated with a hub
 * - hubSiteId: Unique hub site identifier (GUID) from pageContext
 * - hubSiteUrl: Hub site URL (fetched via REST API)
 * - isLoading: Loading state for hub URL fetch
 * - error: Error during hub URL fetch
 *
 * Hub Sites are modern SharePoint feature that allow:
 * - Unified navigation across related sites
 * - Shared branding and theming
 * - Content rollup from associated sites
 * - Centralized search and navigation
 *
 * Use this hook to:
 * - Detect hub site association
 * - Get hub site ID and URL
 * - Implement hub-aware navigation
 *
 * Note: hubSiteUrl is fetched asynchronously via REST API when isHubSite is true.
 *
 * @returns Hub site information (isHubSite, hubSiteId, hubSiteUrl, isLoading, error)
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { isHubSite, hubSiteId, hubSiteUrl, isLoading } = useSPFxHubSiteInfo();
 *
 *   if (!isHubSite) {
 *     return <div>Not part of a hub site</div>;
 *   }
 *
 *   if (isLoading) {
 *     return <Spinner label="Loading hub info..." />;
 *   }
 *
 *   return (
 *     <div>
 *       <h3>Hub Site Info</h3>
 *       <p>Hub ID: {hubSiteId}</p>
 *       <a href={hubSiteUrl}>Go to Hub</a>
 *     </div>
 *   );
 * }
 * ```
 *
 * @example Hub-aware navigation
 * ```tsx
 * function HubNavigation() {
 *   const { isHubSite, hubSiteUrl, isLoading } = useSPFxHubSiteInfo();
 *
 *   if (!isHubSite || isLoading) return null;
 *
 *   return (
 *     <nav>
 *       <a href={hubSiteUrl}>← Back to Hub</a>
 *     </nav>
 *   );
 * }
 * ```
 */
export declare function useSPFxHubSiteInfo(): SPFxHubSiteInfo;
//# sourceMappingURL=useSPFxHubSiteInfo.d.ts.map