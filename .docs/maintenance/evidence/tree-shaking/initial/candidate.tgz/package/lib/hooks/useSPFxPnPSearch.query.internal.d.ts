import type { ISearchBuilder } from '@pnp/sp/search';
import type { UseSPFxPnPSearchOptions } from './useSPFxPnPSearch';
export type SearchQueryBuilderFn = (builder: ISearchBuilder) => ISearchBuilder;
export declare function buildSearchQuery(query: string | SearchQueryBuilderFn, options: UseSPFxPnPSearchOptions | undefined): ISearchBuilder;
//# sourceMappingURL=useSPFxPnPSearch.query.internal.d.ts.map