export declare function escapeODataValue(value: string): string;
export declare function serializeValue(value: unknown): string;
export declare function deserializeValue<T>(rawValue: string): T;
//# sourceMappingURL=useSPFxTenantKeyValueStore.serialization.internal.d.ts.map