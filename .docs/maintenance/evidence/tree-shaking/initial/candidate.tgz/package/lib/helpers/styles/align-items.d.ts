import { SxBaseDescriptor } from './types';
/** Sets alignItems to start without changing display. Uses logical CSS alignment, respecting writing mode and direction.
 * @example sx(alignItems.start)
 */
export declare const start: SxBaseDescriptor;
/** Sets alignItems to center without changing display.
 * @example sx(alignItems.center)
 */
export declare const center: SxBaseDescriptor;
/** Sets alignItems to end without changing display. Uses logical CSS alignment, respecting writing mode and direction.
 * @example sx(alignItems.end)
 */
export declare const end: SxBaseDescriptor;
/** Sets alignItems to stretch without changing display.
 * @example sx(alignItems.stretch)
 */
export declare const stretch: SxBaseDescriptor;
/** Sets alignItems to baseline without changing display.
 * @example sx(alignItems.baseline)
 */
export declare const baseline: SxBaseDescriptor;
//# sourceMappingURL=align-items.d.ts.map