import { SxBaseDescriptor } from './types';
/** Aligns text to start; start/end follow the element's writing direction.
 * @example sx(textAlign.start)
 */
export declare const start: SxBaseDescriptor;
/** Aligns text to center; start/end follow the element's writing direction.
 * @example sx(textAlign.center)
 */
export declare const center: SxBaseDescriptor;
/** Aligns text to end; start/end follow the element's writing direction.
 * @example sx(textAlign.end)
 */
export declare const end: SxBaseDescriptor;
//# sourceMappingURL=text-align.d.ts.map