import type { PageContext } from '@microsoft/sp-page-context';
type SPFxGroupInfoResult = {
    readonly id: string;
    readonly isPublic: boolean;
};
type SPFxTimeZoneResult = {
    readonly id: number;
    readonly offset: number;
    readonly description: string;
    readonly daylightOffset: number;
    readonly standardOffset: number;
};
type SPFxEnvironmentTypeResult = 'Local' | 'SharePoint' | 'SharePointOnPrem' | 'Teams' | 'Office' | 'Outlook';
type SPFxPageTypeResult = 'sitePage' | 'webPartPage' | 'listPage' | 'listFormPage' | 'profilePage' | 'searchPage' | 'unknown';
/**
 * Maps SPFx PageContext user data to the toolkit user info shape.
 *
 * @param pageContext - SPFx page context
 * @returns User information
 */
export declare function getSPFxUserInfo(pageContext: PageContext): {
    readonly loginName: string;
    readonly displayName: string;
    readonly email?: string;
    readonly isExternal: boolean;
};
/**
 * Maps SPFx PageContext site and web data to the toolkit site info shape.
 *
 * @param pageContext - SPFx page context
 * @returns Site collection and web information
 */
export declare function getSPFxSiteInfo(pageContext: PageContext): {
    readonly webId: string;
    readonly webUrl: string;
    readonly webServerRelativeUrl: string;
    readonly title: string;
    readonly languageId: number;
    readonly logoUrl?: string;
    readonly siteId: string;
    readonly siteUrl: string;
    readonly siteServerRelativeUrl: string;
    readonly siteClassification?: string;
    readonly siteGroup?: SPFxGroupInfoResult;
};
/**
 * Maps SPFx PageContext list data to the toolkit list info shape.
 *
 * @param pageContext - SPFx page context
 * @returns List information, or undefined when there is no list context
 */
export declare function getSPFxListInfo(pageContext: PageContext): {
    readonly id: string;
    readonly title: string;
    readonly serverRelativeUrl: string;
    readonly baseTemplate?: number;
    readonly isDocumentLibrary?: boolean;
} | undefined;
/**
 * Maps SPFx PageContext culture and regional data to the toolkit locale info shape.
 *
 * @param pageContext - SPFx page context
 * @returns Locale and regional information
 */
export declare function getSPFxLocaleInfo(pageContext: PageContext): {
    readonly locale: string;
    readonly uiLocale: string;
    readonly timeZone: SPFxTimeZoneResult | undefined;
    readonly isRtl: boolean;
};
/**
 * Maps SPFx PageContext host data to the toolkit environment info shape.
 *
 * @param pageContext - SPFx page context
 * @returns Environment information
 */
export declare function getSPFxEnvironmentInfo(pageContext: PageContext): {
    readonly type: SPFxEnvironmentTypeResult;
    readonly isLocal: boolean;
    readonly isWorkbench: boolean;
    readonly isSharePoint: boolean;
    readonly isSharePointOnPrem: boolean;
    readonly isTeams: boolean;
    readonly isOffice: boolean;
    readonly isOutlook: boolean;
};
/**
 * Detects the current SharePoint page type from modern and legacy page context data.
 *
 * @param pageContext - SPFx page context
 * @returns Page type information
 */
export declare function getSPFxPageTypeInfo(pageContext: PageContext): {
    readonly pageType: SPFxPageTypeResult;
    readonly isModernPage: boolean;
    readonly isSitePage: boolean;
    readonly isListPage: boolean;
    readonly isListFormPage: boolean;
    readonly isWebPartPage: boolean;
};
/**
 * Extracts correlation and tenant IDs from SPFx PageContext.
 *
 * @param pageContext - SPFx page context
 * @returns Correlation and tenant identifiers
 */
export declare function getSPFxCorrelationInfo(pageContext: PageContext): {
    readonly correlationId: string | undefined;
    readonly tenantId: string | undefined;
};
export {};
//# sourceMappingURL=spfx-page-context.helpers.d.ts.map