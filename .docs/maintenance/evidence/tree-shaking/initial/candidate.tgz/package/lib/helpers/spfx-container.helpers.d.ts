/**
 * Gets the Fluent UI 9 aligned SPFx container size category from width.
 *
 * @param width - Container width in pixels
 * @returns Container size category
 */
export declare function getSPFxContainerSize(width: number): 'small' | 'medium' | 'large' | 'xLarge' | 'xxLarge' | 'xxxLarge';
//# sourceMappingURL=spfx-container.helpers.d.ts.map