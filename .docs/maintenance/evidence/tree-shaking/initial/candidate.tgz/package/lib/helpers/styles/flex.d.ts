import { SxBaseDescriptor } from './types';
/** Flex container arranged in a row; gap and alignment remain independent.
 * @example sx(flex.row, gap.medium)
 */
export declare const row: SxBaseDescriptor;
/** Flex container arranged in a column; gap and alignment remain independent.
 * @example sx(flex.column, gap.medium)
 */
export declare const column: SxBaseDescriptor;
/** Allows flex items to wrap without changing display.
 * @example sx(flex.wrap)
 */
export declare const wrap: SxBaseDescriptor;
/** Keeps flex items on one line without changing display.
 * @example sx(flex.noWrap)
 */
export declare const noWrap: SxBaseDescriptor;
//# sourceMappingURL=flex.d.ts.map