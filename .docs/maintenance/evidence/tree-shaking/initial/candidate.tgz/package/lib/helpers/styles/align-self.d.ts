import { SxBaseDescriptor } from './types';
/** Sets alignSelf to auto without changing display.
 * @example sx(alignSelf.auto)
 */
export declare const auto: SxBaseDescriptor;
/** Sets alignSelf to start without changing display. Uses logical CSS alignment, respecting writing mode and direction.
 * @example sx(alignSelf.start)
 */
export declare const start: SxBaseDescriptor;
/** Sets alignSelf to center without changing display.
 * @example sx(alignSelf.center)
 */
export declare const center: SxBaseDescriptor;
/** Sets alignSelf to end without changing display. Uses logical CSS alignment, respecting writing mode and direction.
 * @example sx(alignSelf.end)
 */
export declare const end: SxBaseDescriptor;
/** Sets alignSelf to stretch without changing display.
 * @example sx(alignSelf.stretch)
 */
export declare const stretch: SxBaseDescriptor;
//# sourceMappingURL=align-self.d.ts.map