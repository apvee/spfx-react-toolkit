import type { ISPFXContext, SPFI } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/batching';
export interface SPFxPnPContextServiceConfig {
    cache?: {
        enabled: boolean;
        storage?: 'session' | 'local';
        timeout?: number;
        keyFactory?: (url: string) => string;
    };
    batch?: {
        enabled: boolean;
        maxRequests?: number;
    };
    headers?: Record<string, string>;
}
export interface SPFxPnPPageContextLike {
    web: {
        absoluteUrl: string;
    };
}
export interface SPFxPnPContextService {
    resolveSiteUrl: (siteUrl?: string) => string;
    createSPFI: (siteUrl?: string, config?: SPFxPnPContextServiceConfig) => SPFI;
    getConfigKey: (config?: SPFxPnPContextServiceConfig) => string;
}
export declare function createSPFxPnPContextService(spfxContext: ISPFXContext | undefined, pageContext: SPFxPnPPageContextLike): SPFxPnPContextService;
//# sourceMappingURL=spfx-pnp-context.service.d.ts.map