import type { SxStyleEnvironment } from './renderer.internal';
import type { SxInput } from './types';
/** Materialize only requested properties/assignments, merging in original segment order. */
export declare function resolveSxInputs(environment: SxStyleEnvironment, inputs: readonly SxInput[]): string;
//# sourceMappingURL=resolve.internal.d.ts.map