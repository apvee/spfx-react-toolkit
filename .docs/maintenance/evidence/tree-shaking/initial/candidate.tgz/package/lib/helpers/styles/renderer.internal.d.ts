import type { GriffelRenderer } from '@griffel/core';
import type { SxOptions } from './types';
export interface SxStyleEnvironment {
    readonly renderer: GriffelRenderer;
    readonly dir: 'ltr' | 'rtl';
}
/** Read existing host contexts exactly once per hook render; never create a renderer. */
export declare function useSxStyleEnvironment(options?: SxOptions): SxStyleEnvironment;
//# sourceMappingURL=renderer.internal.d.ts.map