import { SxBaseDescriptor } from './types';
/** Applies box-shadow none without changing geometry.
 * Token shadows require scoped Fluent theme variables.
 * @example sx(boxShadow.none)
 */
export declare const none: SxBaseDescriptor;
/** Applies box-shadow var(--shadow4) without changing geometry.
 * Token shadows require scoped Fluent theme variables.
 * @example sx(boxShadow.small)
 */
export declare const small: SxBaseDescriptor;
/** Applies box-shadow var(--shadow8) without changing geometry.
 * Token shadows require scoped Fluent theme variables.
 * @example sx(boxShadow.medium)
 */
export declare const medium: SxBaseDescriptor;
//# sourceMappingURL=box-shadow.d.ts.map