import { SPHttpClient } from '@microsoft/sp-http';
export interface SPFxTenantProperty<T = unknown> {
    readonly value: T | undefined;
    readonly description: string | undefined;
}
export interface SPFxTenantPropertyService {
    get: <T = unknown>(key: string, catalogUrl: string) => Promise<SPFxTenantProperty<T>>;
}
export declare function createSPFxTenantPropertyService(spHttpClient: SPHttpClient): SPFxTenantPropertyService;
//# sourceMappingURL=spfx-tenant-property.service.d.ts.map