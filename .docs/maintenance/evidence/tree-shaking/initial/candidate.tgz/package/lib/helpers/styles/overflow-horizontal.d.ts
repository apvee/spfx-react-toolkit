import { SxBaseDescriptor } from './types';
/** Sets horizontal overflow to visible; the other axis retains native CSS behavior.
 * CSS can compute visible to auto when the other axis is hidden or auto.
 * @example sx(overflow.horizontal.visible)
 */
export declare const visible: SxBaseDescriptor;
/** Sets horizontal overflow to hidden; the other axis retains native CSS behavior.
 * CSS can compute visible to auto when the other axis is hidden or auto.
 * @example sx(overflow.horizontal.hidden)
 */
export declare const hidden: SxBaseDescriptor;
/** Sets horizontal overflow to auto; the other axis retains native CSS behavior.
 * CSS can compute visible to auto when the other axis is hidden or auto.
 * @example sx(overflow.horizontal.auto)
 */
export declare const auto: SxBaseDescriptor;
//# sourceMappingURL=overflow-horizontal.d.ts.map