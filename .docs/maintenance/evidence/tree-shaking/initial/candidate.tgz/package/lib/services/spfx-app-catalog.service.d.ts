import { SPHttpClient } from '@microsoft/sp-http';
export interface SPFxAppCatalogPageContextLike {
    web: {
        absoluteUrl: string;
    };
}
export interface SPFxAppCatalogService {
    discoverUrl: () => Promise<string>;
    canCurrentUserWrite: (catalogUrl: string) => Promise<boolean>;
}
export declare function createSPFxAppCatalogService(spHttpClient: SPHttpClient | undefined, pageContext: SPFxAppCatalogPageContextLike | undefined): SPFxAppCatalogService;
//# sourceMappingURL=spfx-app-catalog.service.d.ts.map