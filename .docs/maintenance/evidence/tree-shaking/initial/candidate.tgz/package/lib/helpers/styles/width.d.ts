import { SxBaseDescriptor } from './types';
/** Automatic width.
 * @example sx(width.auto)
 */
export declare const auto: SxBaseDescriptor;
/** Full width of the containing block.
 * @example sx(width.full)
 */
export declare const full: SxBaseDescriptor;
/** Creates an explicit pixel width.
 * @param value Finite nonnegative pixel length, including zero.
 * @returns Immutable width descriptor.
 * @throws {RangeError} When value is negative, NaN, or infinite.
 * @example sx(width.px(240))
 */
export declare function px(value: number): SxBaseDescriptor;
//# sourceMappingURL=width.d.ts.map