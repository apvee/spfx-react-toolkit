/**
 * Return type for storage hooks
 */
export interface SPFxStorageHook<T> {
    /** Current value */
    readonly value: T;
    /** Set new value */
    readonly setValue: (value: T | ((prev: T) => T)) => void;
    /** Remove value (reset to default) */
    readonly remove: () => void;
}
/**
 * Hook to use localStorage scoped to SPFx instance
 *
 * The storage key is automatically scoped to the SPFx instance ID,
 * ensuring isolation between different web parts/extensions.
 *
 * Data persists across page reloads and sessions.
 *
 * Use for:
 * - User preferences
 * - Form drafts
 * - Long-lived cache
 * - Settings
 *
 * @param key - Storage key (will be prefixed with instance ID)
 * @param defaultValue - Fallback when initializing a key or removing its value. Changing it alone preserves the current value; remove uses the latest fallback.
 * @returns Storage hook with value, setValue, and remove
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { value, setValue } = useSPFxLocalStorage('view-mode', 'grid');
 *
 *   return (
 *     <div>
 *       <p>View: {value}</p>
 *       <button onClick={() => setValue('list')}>List View</button>
 *       <button onClick={() => setValue('grid')}>Grid View</button>
 *     </div>
 *   );
 * }
 * ```
 */
export declare function useSPFxLocalStorage<T>(key: string, defaultValue: T): SPFxStorageHook<T>;
/**
 * Hook to use sessionStorage scoped to SPFx instance
 *
 * The storage key is automatically scoped to the SPFx instance ID,
 * ensuring isolation between different web parts/extensions.
 *
 * Data persists only for the current browser session/tab.
 *
 * Use for:
 * - Temporary state
 * - Session-specific cache
 * - Tab-specific settings
 * - Wizard state
 *
 * @param key - Storage key (will be prefixed with instance ID)
 * @param defaultValue - Fallback when initializing a key or removing its value. Changing it alone preserves the current value; remove uses the latest fallback.
 * @returns Storage hook with value, setValue, and remove
 *
 * @example
 * ```tsx
 * function WizardComponent() {
 *   const { value: step, setValue: setStep } = useSPFxSessionStorage('wizard-step', 1);
 *
 *   return (
 *     <div>
 *       <p>Step: {step}</p>
 *       <button onClick={() => setStep(s => s + 1)}>Next</button>
 *     </div>
 *   );
 * }
 * ```
 */
export declare function useSPFxSessionStorage<T>(key: string, defaultValue: T): SPFxStorageHook<T>;
//# sourceMappingURL=useSPFxStorage.d.ts.map