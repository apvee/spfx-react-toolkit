import { SxBinding, SxBreakpoint, SxProperty, SxState } from './descriptor.internal';
import { SxInput } from './types';
export type SxQuery = {
    readonly target: 'base';
} | {
    readonly target: 'container' | 'viewport';
    readonly breakpoint: SxBreakpoint;
};
export interface SxNormalizedDeclaration {
    readonly property: SxProperty;
    readonly value: string;
    readonly query: SxQuery;
    readonly state?: SxState;
    readonly binding: SxBinding;
}
export type SxNormalizedSegment = {
    readonly kind: 'class';
    readonly className: string;
} | {
    readonly kind: 'declarations';
    readonly declarations: readonly SxNormalizedDeclaration[];
};
/** Stable scope identity; values never participate in property conflict detection. */
export declare function sxScopeKey(query: SxQuery, state?: SxState): string;
/** Expand recipes in place and deduplicate only inside contiguous descriptor segments. */
export declare function normalizeSxInputs(inputs: readonly SxInput[]): readonly SxNormalizedSegment[];
//# sourceMappingURL=normalize.internal.d.ts.map