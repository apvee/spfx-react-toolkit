import type { GriffelStyle } from '@griffel/core';
import type { SxBinding } from './descriptor.internal';
import { SxNormalizedDeclaration } from './normalize.internal';
/** Fixed property chain permits merging independent sx results without replacing their scopes. */
export declare function createBindingStyle(binding: SxBinding): GriffelStyle;
/** Scoped assignments are ordinary Griffel declarations, never inline style. */
export declare function createAssignmentStyle(declaration: SxNormalizedDeclaration): GriffelStyle;
//# sourceMappingURL=bindings.internal.d.ts.map